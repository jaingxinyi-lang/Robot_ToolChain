#!/bin/bash

# 极简 RTC 掉电保存测试

echo "=== RTC 掉电保存测试 ==="

# 显示当前时间
echo "当前时间:"
date
echo "硬件时钟:"
sudo hwclock -r

echo ""
echo "设置时间为 2026-04-20 10:50:00"

# 设置系统时间并检查结果
if sudo date -s "2026-04-20 10:50:00"; then
    echo "系统时间设置成功"
else
    echo "ERR1200"
    exit 1
fi

# 写入硬件时钟并检查结果
if sudo hwclock -w; then
    echo "硬件时钟写入成功"
else
    echo "ERR1200"
    exit 1
fi

echo ""
echo "设置后时间:"

# 读取系统时间并验证
current_date=$(date "+%Y-%m-%d %H:%M:%S")
echo "系统时间: $current_date"

# 读取硬件时钟并验证
hwclock_time=$(sudo hwclock -r)
echo "硬件时钟: $hwclock_time"

# 验证系统时间是否设置正确
if date "+%Y-%m-%d %H:%M" | grep -q "2026-04-20 10:5[0-9]"; then
    echo "系统时间验证通过"
else
    echo "ERR1200"
    exit 1
fi

# 验证硬件时钟是否写入成功
if sudo hwclock -r | grep -q "2026-04-20 10:5[0-9]"; then
    echo "硬件时钟验证通过"
    echo "SUC1200"
else
    echo "ERR1200"
    exit 1
fi

echo ""
echo "========================================"
echo "请执行以下步骤完成测试:"
echo "1. sudo poweroff        # 断电"
echo "2. 重新上电启动"
echo "3. date                 # 查看时间"
echo "4. sudo hwclock -r      # 查看硬件时钟"
echo ""
echo "预期结果: 时间保持在 2026-04-20 10:50:00 附近"
echo "========================================"



#运行步骤
#1. 运行脚本
#chmod +x RTC.sh
#sudo ./RTC.sh

# 2. 断电重启
#sudo poweroff

# 3. 上电后检查
#date
#sudo hwclock -r