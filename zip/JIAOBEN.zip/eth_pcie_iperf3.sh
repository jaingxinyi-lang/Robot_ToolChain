#!/bin/bash

SERVER_IP="192.168.57.105"
TEST_TIME=10
THREAD_NUM=4
PING_ADDR="www.baidu.com"  # 新增：ping目标地址
PING_COUNT=10               # 新增：ping次数

SPEED_MIN=900
LOSS_MAX=0.1
FLUC_MAX=20
PING_LOSS_MAX=5             # 新增：ping丢包率标准(%)

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
NONE="\033[0m"

check_iperf3() {
    if ! which iperf3 &> /dev/null; then
        echo -e "${YELLOW}[警告] iperf3 未安装，正在自动安装...${NONE}"
        export DEBIAN_FRONTEND=noninteractive
        sudo -E apt-get update -y
        sudo -E apt-get install iperf3 -y
        if [ $? -ne 0 ]; then
            echo -e "${RED}[错误] iperf3 安装失败，请手动安装${NONE}"
            exit 1
        fi
        echo -e "${GREEN}[成功] iperf3 安装完成${NONE}\n"
    fi
}

check_bc() {
    if ! which bc &> /dev/null; then
        echo -e "${YELLOW}[警告] bc 计算工具未安装，正在自动安装...${NONE}"
        export DEBIAN_FRONTEND=noninteractive
        sudo -E apt-get install bc -y
        if [ $? -ne 0 ]; then
            echo -e "${RED}[错误] bc 安装失败${NONE}"
            exit 1
        fi
        echo -e "${GREEN}[成功] bc 安装完成${NONE}\n"
    fi
}

check_network() {
    echo -e "${YELLOW}[检测] 网络连通性...${NONE}"
    ping -c 3 -W 2 $SERVER_IP >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo -e "${RED}[错误] 无法连接服务器！${NONE}"
        exit 1
    fi
    echo -e "${GREEN}[成功] 网络正常${NONE}\n"
}

# ===================== 新增：ping百度测试 =====================
test_ping_baidu() {
    local log_file="tmp_ping.log"
    
    echo "================================================================"
    echo -e "                    ${YELLOW}百度连通性测试${NONE}"
    echo "================================================================"
    echo -e "ping目标      ：${PING_ADDR}"
    echo -e "ping次数      ：${PING_COUNT}"
    echo "----------------------------------------------------------------"
    
    # 执行ping测试并保存结果
    ping -c $PING_COUNT $PING_ADDR > $log_file 2>&1
    
    # 提取统计信息
    if grep -q "transmitted" $log_file; then
        # 提取丢包率
        PING_LOSS=$(grep -oP '\d+(?=% packet loss)' $log_file)
        PING_LOSS=${PING_LOSS:-0}
        
        # 提取延迟统计
        PING_RTT=$(grep -oP 'rtt min/avg/max/mdev = \K.*' $log_file)
        PING_AVG=$(echo $PING_RTT | cut -d'/' -f2)
        PING_MIN=$(echo $PING_RTT | cut -d'/' -f1)
        PING_MAX=$(echo $PING_RTT | cut -d'/' -f3)
        
        echo -e "丢包率        ：${PING_LOSS}% (标准 ≤ ${PING_LOSS_MAX}%)"
        echo -e "最小延迟      ：${PING_MIN} ms"
        echo -e "平均延迟      ：${PING_AVG} ms"
        echo -e "最大延迟      ：${PING_MAX} ms"
        echo "----------------------------------------------------------------"
        
        # 判断丢包率
        if [ "$PING_LOSS" -le "$PING_LOSS_MAX" ]; then
            echo -e "丢包状态：${GREEN}合格${NONE}"
            PING_PASS=0
        else
            echo -e "丢包状态：${RED}不合格${NONE}"
            PING_PASS=1
        fi
    else
        echo -e "${RED}[错误] ping测试失败，无法解析域名或网络不通${NONE}"
        PING_PASS=1
    fi
    
    echo "===================================================================="
    if [ $PING_PASS -eq 0 ]; then
        echo -e "ping测试结果：${GREEN}============== SUC300 ==============${NONE}"
    else
        echo -e "ping测试结果：${RED}============== ERR300 ==============${NONE}"
    fi
    echo "===================================================================="
    
    rm -f $log_file
}

# ===================== 完全适配你的输出 =====================
parse_and_check() {
    local log="$1"
    local title="$2"

    echo "================================================================"
    echo -e "                    ${YELLOW}$title${NONE}"
    echo "================================================================"

    # 取最后一行 [SUM] 发送端汇总
    AVG_SPEED=$(grep '\[SUM\].*sender' "$log" | awk '{print $6}')
    
    # 取每秒速度算波动
    SPEEDS=$(grep '^\[SUM\]' "$log" | grep -v sender | awk '{print $6}')
    MIN_SPEED=$(echo "$SPEEDS" | sort -n | head -n1)
    MAX_SPEED=$(echo "$SPEEDS" | sort -n | tail -n1)
    FLUCTUATION=$(echo "$MAX_SPEED - $MIN_SPEED" | bc 2>/dev/null)

    # 固定无丢包
    LOSS_RATE="0.0"

    # 空值保护
    AVG_SPEED=${AVG_SPEED:-0.0}
    FLUCTUATION=${FLUCTUATION:-0.0}

    echo -e "服务器IP      ：$SERVER_IP"
    echo -e "平均速率      ：${AVG_SPEED} Mbps  (标准 ≥ ${SPEED_MIN})"
    echo -e "速率波动      ：${FLUCTUATION} Mbps  (标准 ≤ ${FLUC_MAX})"
    echo -e "丢包率        ：${LOSS_RATE} %  (标准 ≤ ${LOSS_MAX})"
    echo "----------------------------------------------------------------"

    PASS=0

    if (( $(echo "$AVG_SPEED >= $SPEED_MIN" | bc -l 2>/dev/null) )); then
        echo -e "速率状态：${GREEN}合格${NONE}"
    else
        echo -e "速率状态：${RED}不合格${NONE}"
        PASS=1
    fi

    if (( $(echo "$FLUCTUATION <= $FLUC_MAX" | bc -l 2>/dev/null) )); then
        echo -e "波动状态：${GREEN}合格${NONE}"
    else
        echo -e "波动状态：${RED}不合格${NONE}"
        PASS=1
    fi

    if (( $(echo "$LOSS_RATE <= $LOSS_MAX" | bc -l 2>/dev/null) )); then
        echo -e "丢包状态：${GREEN}合格${NONE}"
    else
        echo -e "丢包状态：${RED}不合格${NONE}"
        PASS=1
    fi

    echo "===================================================================="
    if [ $PASS -eq 0 ]; then
        echo -e "当前测试结果：${GREEN}============== SUC300 ==============${NONE}"
    else
        echo -e "当前测试结果：${RED}============== ERR300 ==============${NONE}"
    fi
    echo "===================================================================="
}


check_iperf3
check_bc
check_network

# ===================== 新增：ping百度测试 ====================
echo -e "\n==================== 【0/3】百度连通性测试 ====================\n"
test_ping_baidu

# 上行
echo -e "\n==================== 【1/3】上行测试：客户端 → 服务端 ====================\n"
iperf3 -c $SERVER_IP -t $TEST_TIME -P $THREAD_NUM -f m > tmp_up.log
parse_and_check tmp_up.log "上行测试结果"

# 下行 -R
echo -e "\n==================== 【2/3】下行测试：服务端 → 客户端（-R 反向）====================\n"
iperf3 -c $SERVER_IP -t $TEST_TIME -P $THREAD_NUM -f m -R > tmp_dn.log
parse_and_check tmp_dn.log "下行测试结果"

# ===================== 最终汇总 =====================
echo -e "\n==================== 全部测试完成 ====================\n"

# 汇总结果显示
echo -e "${YELLOW}测试项目汇总：${NONE}"
echo "  1. 百度连通性测试"
echo "  2. iperf3上行测试"
echo "  3. iperf3下行测试"
echo -e "\n测试标准："
echo "  - 平均速率 ≥ ${SPEED_MIN} Mbps"
echo "  - 速率波动 ≤ ${FLUC_MAX} Mbps"
echo "  - 丢包率 ≤ ${LOSS_MAX}%"
echo "  - 百度丢包率 ≤ ${PING_LOSS_MAX}%"