#!/bin/bash

# ==================== 自动获取sudo权限 ====================
if [ "$EUID" -ne 0 ]; then 
    echo "=========================================="
    echo "需要root权限才能运行此脚本"
    echo "正在自动获取sudo权限..."
    echo "=========================================="
    exec sudo "$0" "$@"
    exit
fi

# ==================== 配置区域 ====================
USB_MOUNT="/media/noetix/TSU10"                         # U盘挂载路径
USB_DEVICE="/dev/sda1"                                   # U盘设备（根据lsblk输出）
LOCAL_FILE="/home/noetix/jiaoben/111/test_200mb.bin"    # 本地测试文件
USB_FILE="$USB_MOUNT/test_copy_$(date +%s).bin"         # U盘临时文件
DOWNLOAD_BACK="$HOME/test_download_back.bin"            # 下载回本地临时文件

# ==================== 全局状态变量 ====================
TEST_STATUS="SUCCESS"  # SUCCESS 或 FAILED
WRITE_SPEED=0
READ_SPEED=0

# ==================== 函数定义 ====================
# 创建挂载点
create_mount_point() {
    if [ ! -d "$USB_MOUNT" ]; then
        echo "正在创建挂载点: $USB_MOUNT"
        mkdir -p "$USB_MOUNT"
        if [ $? -ne 0 ]; then
            echo "✗ 挂载点创建失败"
            TEST_STATUS="FAILED"
            return 1
        fi
        echo "✓ 挂载点创建成功"
    fi
    return 0
}

# 挂载U盘
mount_usb() {
    # 检查是否已经挂载
    if mountpoint -q "$USB_MOUNT"; then
        echo "U盘已经挂载到 $USB_MOUNT"
        return 0
    fi
    
    # 检查设备是否存在
    if [ ! -b "$USB_DEVICE" ]; then
        echo "错误：设备 $USB_DEVICE 不存在"
        echo "可用的USB设备："
        lsblk | grep -E "^sda|^sdb|^sdc"
        TEST_STATUS="FAILED"
        return 1
    fi
    
    echo "正在挂载 $USB_DEVICE 到 $USB_MOUNT"
    mount "$USB_DEVICE" "$USB_MOUNT"
    
    if [ $? -ne 0 ]; then
        echo "✗ U盘挂载失败"
        echo "尝试手动挂载: mount $USB_DEVICE $USB_MOUNT"
        TEST_STATUS="FAILED"
        return 1
    fi
    
    echo "✓ U盘挂载成功"
    return 0
}

# 卸载U盘
umount_usb() {
    if mountpoint -q "$USB_MOUNT"; then
        echo "正在卸载U盘..."
        sync  # 确保数据写入完成
        umount "$USB_MOUNT"
        if [ $? -eq 0 ]; then
            echo "✓ U盘已卸载"
        else
            echo "⚠ 警告：U盘卸载失败，可能需要手动卸载"
        fi
    fi
}

# 输出最终结果
print_result() {
    echo ""
    echo "=========================================="
    if [ "$TEST_STATUS" = "SUCCESS" ]; then
        echo "SUC500"
    else
        echo "ERR500"
    fi
    echo "=========================================="
}

# ==================== 主程序开始 ====================
echo "=========================================="
echo "        U盘传输速率测试工具"
echo "=========================================="
echo "测试时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "USB设备: $USB_DEVICE"
echo "U盘挂载点: $USB_MOUNT"
echo "本地测试文件: $LOCAL_FILE"
echo ""

# 1. 创建挂载点
create_mount_point
if [ "$TEST_STATUS" = "FAILED" ]; then
    print_result
    exit 1
fi

# 2. 挂载U盘
mount_usb
if [ "$TEST_STATUS" = "FAILED" ]; then
    print_result
    exit 1
fi

# 3. 检查本地文件
if [ ! -f "$LOCAL_FILE" ]; then
    echo "错误：文件 '$LOCAL_FILE' 不存在！"
    TEST_STATUS="FAILED"
    umount_usb
    print_result
    exit 1
fi

FILE_SIZE=$(ls -lh "$LOCAL_FILE" | awk '{print $5}')
FILE_SIZE_MB=$(stat -c%s "$LOCAL_FILE" | awk '{printf "%.0f", $1/1024/1024}')
echo "✓ 测试文件大小: $FILE_SIZE"

# 验证文件大小有效
if [ "$FILE_SIZE_MB" -le 0 ]; then
    echo "错误：测试文件大小为0或无法读取"
    TEST_STATUS="FAILED"
    umount_usb
    print_result
    exit 1
fi
echo ""

# 4. 检查U盘可用空间
USB_AVAIL=$(df -BM "$USB_MOUNT" | tail -1 | awk '{print $4}' | sed 's/M//')
if [ -z "$USB_AVAIL" ] || [ "$USB_AVAIL" -lt "$FILE_SIZE_MB" ]; then
    echo "错误：U盘可用空间不足 (需要 ${FILE_SIZE_MB}MB, 可用 ${USB_AVAIL:-未知}MB)"
    TEST_STATUS="FAILED"
    umount_usb
    print_result
    exit 1
fi
echo "✓ U盘可用空间: ${USB_AVAIL}MB"
echo ""

# ==================== 测试1: 写入速度（本地 -> U盘） ====================
echo "------------------------------------------"
echo "【测试1】写入测试 (本地硬盘 -> U盘)"
echo "------------------------------------------"
echo "正在写入文件到U盘..."

# 清空系统缓存
sync
echo 3 > /proc/sys/vm/drop_caches

# 计时开始
START=$(date +%s.%N)

# 使用dd的direct模式绕过缓存
dd if="$LOCAL_FILE" of="$USB_FILE" oflag=direct bs=1M 2>/dev/null
DD_STATUS=$?

# 强制同步
sync

# 计时结束
END=$(date +%s.%N)

if [ $DD_STATUS -eq 0 ] && [ -f "$USB_FILE" ]; then
    WRITE_TIME=$(echo "$END - $START" | bc 2>/dev/null)
    # 处理时间格式，确保bc能正确计算
    if [ -n "$WRITE_TIME" ] && [ "$WRITE_TIME" != "0" ]; then
        WRITE_TIME_CLEAN=$(echo "$WRITE_TIME" | sed 's/^\./0./')
        WRITE_SPEED=$(echo "scale=2; $FILE_SIZE_MB / $WRITE_TIME_CLEAN" | bc 2>/dev/null)
        echo "✓ 写入完成"
        printf ">> 写入速度: %.2f MB/s (用时 %.3f 秒)\n" "${WRITE_SPEED:-0}" "${WRITE_TIME_CLEAN:-0}"
    else
        echo "✗ 写入时间计算失败"
        TEST_STATUS="FAILED"
    fi
else
    echo "✗ 写入失败"
    TEST_STATUS="FAILED"
fi

echo ""

# ==================== 测试2: 读取速度（U盘 -> 本地） ====================
echo "------------------------------------------"
echo "【测试2】读取测试 (U盘 -> 本地硬盘)"
echo "------------------------------------------"

# 只有写入成功才进行读取测试
if [ "$TEST_STATUS" = "SUCCESS" ]; then
    echo "正在从U盘读取文件..."

    # 清空系统缓存
    sync
    echo 3 > /proc/sys/vm/drop_caches

    # 计时开始
    START=$(date +%s.%N)

    # 使用dd的direct模式绕过缓存
    dd if="$USB_FILE" of="$DOWNLOAD_BACK" iflag=direct bs=1M 2>/dev/null
    DD_STATUS=$?

    # 强制同步
    sync

    # 计时结束
    END=$(date +%s.%N)

    if [ $DD_STATUS -eq 0 ] && [ -f "$DOWNLOAD_BACK" ]; then
        READ_TIME=$(echo "$END - $START" | bc 2>/dev/null)
        if [ -n "$READ_TIME" ] && [ "$READ_TIME" != "0" ]; then
            READ_TIME_CLEAN=$(echo "$READ_TIME" | sed 's/^\./0./')
            READ_SPEED=$(echo "scale=2; $FILE_SIZE_MB / $READ_TIME_CLEAN" | bc 2>/dev/null)
            echo "✓ 读取完成"
            printf ">> 读取速度: %.2f MB/s (用时 %.3f 秒)\n" "${READ_SPEED:-0}" "${READ_TIME_CLEAN:-0}"
        else
            echo "✗ 读取时间计算失败"
            TEST_STATUS="FAILED"
        fi
    else
        echo "✗ 读取失败"
        TEST_STATUS="FAILED"
    fi
else
    echo "⚠ 跳过读取测试（写入测试失败）"
fi

echo ""

# ==================== 数据完整性校验 ====================
echo "------------------------------------------"
echo "【数据完整性校验】"
echo "------------------------------------------"

if [ "$TEST_STATUS" = "SUCCESS" ]; then
    LOCAL_MD5=$(md5sum "$LOCAL_FILE" 2>/dev/null | awk '{print $1}')
    USB_MD5=$(md5sum "$USB_FILE" 2>/dev/null | awk '{print $1}')
    DOWNLOAD_MD5=$(md5sum "$DOWNLOAD_BACK" 2>/dev/null | awk '{print $1}')

    if [ -n "$LOCAL_MD5" ] && [ -n "$USB_MD5" ] && [ -n "$DOWNLOAD_MD5" ]; then
        if [ "$LOCAL_MD5" = "$USB_MD5" ] && [ "$LOCAL_MD5" = "$DOWNLOAD_MD5" ]; then
            echo "✓ 文件完整性校验通过 (MD5一致)"
        else
            echo "✗ 警告：文件MD5不一致"
            echo "  本地文件: ${LOCAL_MD5:-获取失败}"
            echo "  U盘文件:  ${USB_MD5:-获取失败}"
            echo "  下载文件: ${DOWNLOAD_MD5:-获取失败}"
            TEST_STATUS="FAILED"
        fi
    else
        echo "✗ MD5校验失败：无法读取文件校验和"
        TEST_STATUS="FAILED"
    fi
else
    echo "⚠ 跳过完整性校验（前置测试失败）"
    TEST_STATUS="FAILED"
fi

# ==================== 清理临时文件 ====================
echo ""
echo "------------------------------------------"
echo "正在清理临时文件..."
rm -f "$USB_FILE" "$DOWNLOAD_BACK" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✓ 清理完成"
else
    echo "⚠ 清理临时文件时出现警告（不影响测试结果）"
fi

# ==================== 卸载U盘 ====================
echo ""
echo "------------------------------------------"
echo "正在卸载U盘..."
umount_usb

# ==================== 结果汇总 ====================
echo ""
echo "=========================================="
echo "            测试结果汇总"
echo "=========================================="
echo "测试文件: $LOCAL_FILE"
echo "文件大小: $FILE_SIZE"
echo "USB设备: $USB_DEVICE -> $USB_MOUNT"
echo ""

# 安全输出速度值
if [ "${WRITE_SPEED:-0}" != "0" ]; then
    printf "写入速度 (写U盘): %.2f MB/s\n" "${WRITE_SPEED:-0}"
else
    echo "写入速度 (写U盘): 测试失败"
fi

if [ "${READ_SPEED:-0}" != "0" ]; then
    printf "读取速度 (读U盘): %.2f MB/s\n" "${READ_SPEED:-0}"
else
    echo "读取速度 (读U盘): 测试失败"
fi

echo "=========================================="

# ==================== 输出最终结果码 ====================
print_result

# 根据测试状态返回退出码
if [ "$TEST_STATUS" = "SUCCESS" ]; then
    exit 0
else
    exit 1
fi