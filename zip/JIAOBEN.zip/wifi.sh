#!/bin/bash

# ==================== 配置参数 ====================
PC_IP="$1"
TEST_TIME=10
THREAD_NUM=1

SPEED_MIN=900
LOSS_MAX=0.1
FLUC_MAX=20

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
NONE="\033[0m"

# ==================== 函数定义 ====================
check_iperf3() {
    if ! which iperf3 &> /dev/null; then
        echo -e "${YELLOW}[警告] iperf3 未安装，正在自动安装...${NONE}"
        # 关键修复：设置非交互模式，避免 debconf 配置卡住
        export DEBIAN_FRONTEND=noninteractive
        sudo -E apt-get update -y
        sudo -E apt-get install iperf3 -y
        if [ $? -ne 0 ]; then
            echo -e "${RED}[错误] iperf3 安装失败，请手动安装${NONE}"
            echo -e "${RED}ERR1000${NONE}"
            exit 1
        fi
        echo -e "${GREEN}[成功] iperf3 安装完成${NONE}"
        echo -e "${GREEN}SUC1000${NONE}\n"
    fi
}

check_bc() {
    if ! which bc &> /dev/null; then
        echo -e "${YELLOW}[警告] bc 计算工具未安装，正在自动安装...${NONE}"
        export DEBIAN_FRONTEND=noninteractive
        sudo -E apt-get install bc -y
        if [ $? -ne 0 ]; then
            echo -e "${RED}[错误] bc 安装失败${NONE}"
            echo -e "${RED}ERR1000${NONE}"
            exit 1
        fi
        echo -e "${GREEN}[成功] bc 安装完成${NONE}"
        echo -e "${GREEN}SUC1000${NONE}\n"
    fi
}

check_param() {
    if [ -z "$PC_IP" ]; then
        echo -e "${RED}[错误] 请传入PC IP${NONE}"
        echo -e "${RED}ERR1000${NONE}"
        exit 1
    fi
    echo -e "${GREEN}[INFO] 已读取PC服务端IP：$PC_IP${NONE}"
    echo -e "${GREEN}SUC1000${NONE}"
}

get_rk3576_ip() {
    # 获取wlan0的IP地址
    local ip=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    
    # 如果wlan0没有IP，尝试其他常见WiFi接口
    if [ -z "$ip" ]; then
        ip=$(ip addr show wlp2s0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    fi
    if [ -z "$ip" ]; then
        ip=$(ip addr show wlan1 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    fi
    
    echo "$ip"
}

# ==================== 新增：ping 百度检测网络连通性 ====================
# ==================== 互联网连接检测（优化版）====================
check_internet() {
    echo -e "\n${YELLOW}============ 互联网连接检测 ============${NONE}"
    echo -e "${YELLOW}[检测] 正在 ping www.baidu.com ...${NONE}"
    
    # 使用 timeout 确保不会卡死，最多 5 秒
    local ping_result=$(timeout 5 ping -c 2 -W 2 www.baidu.com 2>&1)
    local ping_status=$?
    
    if [ $ping_status -eq 0 ]; then
        local avg_latency=$(echo "$ping_result" | tail -1 | awk -F '/' '{print $5}')
        echo -e "${GREEN}[结果] 互联网连接正常${NONE}"
        echo -e "${GREEN}[信息] 平均延迟：${avg_latency} ms${NONE}"
        echo -e "${GREEN}SUC1000${NONE}"
    else
        echo -e "${YELLOW}[警告] 无法连接互联网（不影响局域网测速）${NONE}"
        echo -e "${YELLOW}SUC1000${NONE}"
    fi
    echo -e "${YELLOW}========================================${NONE}\n"
}

wait_for_network() {
    echo -e "${YELLOW}[等待] RK3576 获取WiFi IP...${NONE}"
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        LOCAL_IP=$(get_rk3576_ip)
        
        # 检查是否获取到了有效的IPv4地址（不是127.0.0.1）
        if [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "127.0.0.1" ]; then
            # 验证IP格式
            if [[ $LOCAL_IP =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                echo -e "${GREEN}[检测] RK3576 IP: $LOCAL_IP${NONE}"
                echo -e "${GREEN}SUC1000${NONE}"
                break
            fi
        fi
        sleep 2
        ((attempt++))
    done
    
    if [ $attempt -ge $max_attempts ]; then
        echo -e "${RED}[错误] WiFi IP 获取失败，请检查WiFi连接${NONE}"
        echo -e "${RED}ERR1000${NONE}"
        exit 1
    fi

    # 检查是否能与PC通信（自动判断是否在同一网段）
    echo -e "${YELLOW}[等待] 测试与PC $PC_IP 的连接...${NONE}"
    local ping_attempts=0
    local max_ping_attempts=30
    
    while [ $ping_attempts -lt $max_ping_attempts ]; do
        if ping -c 3 -W 2 $PC_IP &> /dev/null; then
            echo -e "${GREEN}[检测] 网络连接正常，可以与PC通信${NONE}"
            echo -e "${GREEN}SUC1000${NONE}"
            
            # 计算子网
            local subnet=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}')
            if [ -n "$subnet" ]; then
                echo -e "${GREEN}[信息] RK3576网络配置：$subnet${NONE}"
            fi
            
            break
        fi
        sleep 2
        ((ping_attempts++))
    done
    
    if [ $ping_attempts -ge $max_ping_attempts ]; then
        echo -e "${RED}[错误] 无法ping通PC $PC_IP，请检查网络配置${NONE}"
        echo -e "${YELLOW}[提示] RK3576 IP: $LOCAL_IP${NONE}"
        echo -e "${YELLOW}[提示] PC IP: $PC_IP${NONE}"
        echo -e "${YELLOW}[提示] 请确保两者在同一网络或路由可达${NONE}"
        echo -e "${RED}ERR1000${NONE}"
        exit 1
    fi
}

wait_for_iperf_server() {
    echo -e "${YELLOW}[等待] iperf3 服务...${NONE}"
    local max_attempts=15
    local attempt=0
    while [ $attempt -lt $max_attempts ]; do
        timeout 2 bash -c "echo >/dev/tcp/$PC_IP/5201" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}[检测] iperf3 服务正常${NONE}"
            echo -e "${GREEN}SUC1000${NONE}"
            return 0
        fi
        sleep 2
        ((attempt++))
    done
    echo -e "${RED}[错误] iperf3 服务未启动${NONE}"
    echo -e "${RED}ERR1000${NONE}"
    exit 1
}

# ==================== 修复：正确解析英文 iperf3 日志 ====================
parse_and_check() {
    local log="$1"
    local title="$2"

    echo "================================================================"
    echo -e "                    ${YELLOW}$title${NONE}"
    echo "================================================================"

    # 修复：正确解析 iperf3 输出
    # sender 行格式： [SUM]  0.00-10.00  sec   121 MBytes   102 Mbits/sec  sender
    # 间隔行格式：  [  5]   6.00-7.00   sec  12.0 MBytes   101 Mbits/sec
    
    # 解析平均速率（取最后一行 sender 汇总）
    AVG_SPEED=$(grep 'sender' "$log" | tail -n1 | grep -oP '[\d.]+(?=\s+Mbits/sec)')
    
    # 解析所有秒级速率（只取包含 "-" 和 "Mbits/sec" 的间隔行，排除 SUM 和 receiver）
    # 用 grep -oP 精确提取 Mbits/sec 前面的数字
    SPEEDS=$(grep -P '\d+\.\d+-\d+\.\d+\s+sec' "$log" | grep -v 'receiver' | grep -oP '[\d.]+(?=\s+Mbits/sec)')
    
    MIN_SPEED=0
    MAX_SPEED=0
    FLUCTUATION=0
    if [ -n "$SPEEDS" ]; then
        MIN_SPEED=$(echo "$SPEEDS" | sort -n | head -n1)
        MAX_SPEED=$(echo "$SPEEDS" | sort -n | tail -n1)
        FLUCTUATION=$(echo "$MAX_SPEED - $MIN_SPEED" | bc 2>/dev/null)
    fi

    # 丢包率（UDP 才会有，TCP 默认 0）
    LOSS_RATE=$(grep -oP '[\d.]+(?=\%)' "$log" | head -n1)
    LOSS_RATE=${LOSS_RATE:-0.0}
    AVG_SPEED=${AVG_SPEED:-0.0}
    FLUCTUATION=${FLUCTUATION:-0.0}

    echo -e "PC IP         ：$PC_IP"
    echo -e "本机IP        ：$LOCAL_IP"
    echo -e "平均速率      ：${AVG_SPEED} Mbps  (≥ ${SPEED_MIN})"
    echo -e "速率波动      ：${FLUCTUATION} Mbps  (≤ ${FLUC_MAX})"
    echo -e "丢包率        ：${LOSS_RATE} %  (≤ ${LOSS_MAX})"
    echo "----------------------------------------------------------------"

    local test_pass=0
    # 速率判断
    if (( $(echo "$AVG_SPEED >= $SPEED_MIN" | bc -l) )); then
        echo -e "速率状态：${GREEN}合格${NONE}"
    else
        echo -e "速率状态：${RED}不合格${NONE}"
        test_pass=1
    fi
    # 波动判断
    if (( $(echo "$FLUCTUATION <= $FLUC_MAX" | bc -l) )); then
        echo -e "波动状态：${GREEN}合格${NONE}"
    else
        echo -e "波动状态：${RED}不合格${NONE}"
        test_pass=1
    fi
    # 丢包判断
    if (( $(echo "$LOSS_RATE <= $LOSS_MAX" | bc -l) )); then
        echo -e "丢包状态：${GREEN}合格${NONE}"
    else
        echo -e "丢包状态：${RED}不合格${NONE}"
        test_pass=1
    fi

    echo "================================================================"
    if [ $test_pass -eq 0 ]; then
        echo -e "当前测试结果：${GREEN}SUC1000${NONE}"
        return 0
    else
        echo -e "当前测试结果：${RED}ERR1000${NONE}"
        return 1
    fi
}

# ==================== 主流程 ====================
check_param
check_iperf3
check_bc
wait_for_network

# 在 wait_for_network 之后添加互联网检测
check_internet

wait_for_iperf_server

echo -e "\n==================== 【1/2】上行测试 ====================\n"
iperf3 -c $PC_IP -t $TEST_TIME -P $THREAD_NUM -f m > tmp_up.log
UP_RESULT=$?
parse_and_check tmp_up.log "上行测试 RK3576 -> PC"
UP_TEST_PASS=$?

echo -e "\n==================== 【2/2】下行测试 ====================\n"
iperf3 -c $PC_IP -t $TEST_TIME -P $THREAD_NUM -f m -R > tmp_dn.log
DOWN_RESULT=$?
parse_and_check tmp_dn.log "下行测试 PC -> RK3576"
DOWN_TEST_PASS=$?

rm -f tmp_up.log tmp_dn.log

echo -e "\n==================== 双向WiFi测速全部完成 ===================="
echo "================================================================"

# 最终统一判断
if [ $UP_TEST_PASS -eq 0 ] && [ $DOWN_TEST_PASS -eq 0 ]; then
    echo -e "最终测试结果：${GREEN}SUC1000${NONE}"
else
    echo -e "最终测试结果：${RED}ERR1000${NONE}"
fi
echo "================================================================"
exit 0