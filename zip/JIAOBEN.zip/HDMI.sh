#!/bin/bash

#===============================================================================
# HDMI屏幕点亮测试脚本
# 功能：检测HDMI连接状态，验证屏幕显示是否正常
#===============================================================================

# 颜色变量已清空
RED=''
GREEN=''
YELLOW=''
NC=''

#===============================================================================
# 函数：打印成功信息
#===============================================================================
print_success() {
    echo "[PASS] $1"
}

#===============================================================================
# 函数：打印失败信息
#===============================================================================
print_fail() {
    echo "[FAIL] $1"
}

#===============================================================================
# 函数：打印警告信息
#===============================================================================
print_warn() {
    echo "[WARN] $1"
}

#===============================================================================
# 函数：检测HDMI连接状态
#===============================================================================
check_hdmi_connection() {
    echo "=========================================="
    echo "开始HDMI屏幕测试..."
    echo "测试时间: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "=========================================="

    local hdmi_connected=false

    # 方法1: 通过sysfs检测HDMI连接状态
    echo "检测方法1: 读取/sys/class/drm/目录下的HDMI状态..."

    for card in /sys/class/drm/card*-HDMI-A-*/status; do
        if [ -f "$card" ]; then
            status=$(cat "$card" 2>/dev/null)
            echo "  $card : $status"
            if [ "$status" = "connected" ]; then
                hdmi_connected=true
            fi
        fi
    done

    # 方法2: 通过xrandr检测显示器连接
    if command -v xrandr &> /dev/null; then
        echo "检测方法2: 使用xrandr检测显示器连接..."
        xrandr_output=$(xrandr 2>/dev/null)
        
        if echo "$xrandr_output" | grep -q "HDMI.*connected"; then
            hdmi_connected=true
            echo "  xrandr检测到HDMI已连接"
            echo "$xrandr_output" | grep "HDMI.*connected" | while read -r line; do
                echo "  $line"
            done
        fi
    else
        print_warn "xrandr未安装，跳过该检测方法"
    fi

    # 方法3: 通过dmesg检测HDMI热插拔事件
    echo "检测方法3: 检查内核日志中的HDMI事件..."
    dmesg | grep -i "hdmi" | tail -5 | while read -r line; do
        echo "  $line"
    done

    if $hdmi_connected; then
        return 0
    else
        return 1
    fi
}

#===============================================================================
# 函数：检查显示分辨率和刷新率
#===============================================================================
check_display_resolution() {
    echo ""
    echo "=========================================="
    echo "检查显示参数..."
    echo "=========================================="

    if command -v xrandr &> /dev/null; then
        resolution=$(xrandr 2>/dev/null | grep -w "connected" | grep -oP '\d+x\d+[^\s]*' | head -1)
        if [ -n "$resolution" ]; then
            echo "当前分辨率: $resolution"
            print_success "分辨率检测正常"
        else
            # 尝试从sysfs获取分辨率
            for card in /sys/class/drm/card*-HDMI-A-*/modes; do
                if [ -f "$card" ]; then
                    mode=$(head -1 "$card" 2>/dev/null)
                    if [ -n "$mode" ]; then
                        echo "当前模式: $mode"
                        print_success "显示模式检测正常"
                    fi
                fi
            done
        fi
    fi
}

#===============================================================================
# 函数：检测显示色彩是否有异常
#===============================================================================
check_color_normal() {
    echo ""
    echo "=========================================="
    echo "色彩检测提示..."
    echo "=========================================="
    echo "注意: 脚本无法自动检测色彩是否正常，请肉眼观察以下内容:"
    echo "  1. 屏幕是否完全点亮（无黑屏区域）"
    echo "  2. 颜色是否正常（无偏色、花屏、条纹）"
    echo "  3. 亮度是否均匀"
    echo "  4. 是否有闪烁现象"
    echo ""
}

#===============================================================================
# 函数：检查系统是否检测到屏幕并成功设置显示
#===============================================================================
check_system_display_status() {
    echo ""
    echo "=========================================="
    echo "检查系统显示状态..."
    echo "=========================================="

    # 检查framebuffer设备
    if [ -e /dev/fb0 ]; then
        echo "Framebuffer设备 /dev/fb0 存在"
        print_success "Framebuffer设备已就绪"
    else
        print_warn "未检测到 /dev/fb0 设备"
    fi

    # 检查显示相关的进程
    if pgrep -x "Xorg" > /dev/null || pgrep -x "X" > /dev/null; then
        echo "X Server 正在运行"
        print_success "X Server运行正常"
    fi

    if pgrep -x "weston" > /dev/null; then
        echo "Wayland (Weston) 正在运行"
        print_success "Wayland运行正常"
    fi
}

#===============================================================================
# 主函数
#===============================================================================
main() {
    echo "HDMI屏幕点亮测试脚本启动"
    echo "脚本版本: 1.0"
    echo ""

    # 检查是否为root用户
    if [ "$EUID" -ne 0 ]; then
        print_warn "建议以root权限运行此脚本以获得完整的检测信息"
    fi

    local test_result=0

    # 测试1: HDMI连接状态检测
    if check_hdmi_connection; then
        print_success "HDMI屏幕连接正常，已成功检测到显示设备"
    else
        print_fail "未检测到HDMI屏幕连接"
        print_warn "请检查:"
        print_warn "  1. HDMI线是否牢固连接"
        print_warn "  2. 屏幕电源是否打开"
        print_warn "  3. 屏幕信号源是否选择正确"
        test_result=1
    fi

    # 测试2: 显示分辨率检查
    check_display_resolution

    # 测试3: 系统显示状态检查
    check_system_display_status

    # 测试4: 色彩检测提示
    check_color_normal

    # 汇总测试结果
    echo ""
    echo "=========================================="
    echo "            测试结果汇总"
    echo "=========================================="
    
    if [ $test_result -eq 0 ]; then
        echo ""
        print_success "屏幕正常点亮，系统显示功能正常"
        echo ""
        echo "检查项目:"
        echo "  ✅ HDMI物理连接正常"
        echo "  ✅ 屏幕成功进入系统显示"
        echo "  ✅ 显示参数检测正常"
        echo "  ⚠️  请手动确认色彩无异常"
        echo ""
        echo "测试结论: 通过"
        echo ""
        echo "SUC007"
    else
        echo ""
        print_fail "屏幕测试未通过，请检查硬件连接和配置"
        echo ""
        echo "测试结论: 失败"
        echo ""
        echo "ERR007"
    fi

    echo ""
    
    return $test_result
}

#===============================================================================
# 脚本入口
#===============================================================================
main
exit $?