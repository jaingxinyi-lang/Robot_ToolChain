#include "led_driver.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <signal.h> 
#include <pthread.h>

#define LED_NUM 6

unsigned char send_buf[24*LED_NUM];
int fd = -1;

int spi_init(const char *spi_dev)
{
    int fd_spidev;
    int ret; 
    SPI_MODE mode;
    char spi_bits;
    SPI_SPEED spi_speed;

    fd_spidev = open(spi_dev, O_RDWR);
	if (fd_spidev < 0) 
    {
		printf("open %s err\n", spi_dev);
		return -1;
	}

    mode = SPIMODE3;
    ret = ioctl(fd_spidev, SPI_IOC_WR_MODE, &mode);
    if (ret < 0) 
    {
		printf("SPI_IOC_WR_MODE err\n");
		return -1;
	}

    spi_bits = 8;
    ret = ioctl(fd_spidev, SPI_IOC_WR_BITS_PER_WORD, &spi_bits);
    if (ret < 0) 
    {
		printf("SPI_IOC_WR_BITS_PER_WORD err\n");
		return -1;
	}

    spi_speed = (SPI_SPEED)S_8M;
    ret = ioctl(fd_spidev, SPI_IOC_WR_MAX_SPEED_HZ, &spi_speed);
    if (ret < 0) 
    {
		printf("SPI_IOC_WR_MAX_SPEED_HZ err\n");
		return -1;
	}

    return fd_spidev;
}

int spi_write_nbyte_data(unsigned int fd_spidev, unsigned char *send_buf, unsigned int send_buf_len)
{
    struct spi_ioc_transfer	xfer[2];
    unsigned char recv_buf[send_buf_len];
	int status;

    if(send_buf == NULL || send_buf_len < 1)
        return -1;

    memset(xfer, 0, sizeof(xfer));
    memset(recv_buf, 0, sizeof(send_buf_len));

	xfer[0].tx_buf = (unsigned long)send_buf;
    xfer[0].rx_buf = (unsigned long)recv_buf;
	xfer[0].len = send_buf_len;

	status = ioctl(fd_spidev, SPI_IOC_MESSAGE(1), xfer);
	if (status < 0) 
    {
		perror("SPI_IOC_MESSAGE");
		return -1;
	}

    return 0;
}

void update_sendbuff(unsigned char led_id, unsigned char r, unsigned char g, unsigned char b)
{
    int i = 0;
    int index = led_id*24;

    i += index;
    for ( ; i < (index+8); i++) 
    {
        send_buf[i] = (g & 0x80) ? (0xFC) : (0xC0);		
        g <<= 1;		
    }

    for (; i < (index+16); i++) 
    {
        send_buf[i] = (r & 0x80) ? (0xFC) : (0xC0);	
        r <<= 1;			
    }
    
    for (; i < (index+24); i++) 
    {
        send_buf[i] = (b & 0x80) ? (0xFC) : (0xC0);	
        b <<= 1;			
    }
}

int led_init()
{
   fd = spi_init("/dev/spidev3.1");
   if(fd < 0)
   {
        printf("LED初始化失败: SPI设备打开失败\n");
        return -1;
   }
   return 0;
}

int led_is_initialized()
{
    return (fd >= 0);
}

void led_rgb_update(unsigned char r, unsigned char g, unsigned char b)
{
    if (fd < 0) {
        printf("警告: LED未初始化，无法更新颜色\n");
        return;
    }

    for (int i=0; i < LED_NUM; i++)
    {
        update_sendbuff(i, r, g, b);
    }
    
    int ret = spi_write_nbyte_data(fd, send_buf, sizeof(send_buf));
    if (ret < 0) {
        printf("SPI写入失败\n");
    }
}