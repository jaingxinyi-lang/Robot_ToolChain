#!/bin/bash
sudo ./imu_test
