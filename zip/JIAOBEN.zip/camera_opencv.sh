#!/bin/bash
# Camera MJPEG streaming test for Robot_ToolChain.
# Launches a Python+OpenCV MJPEG HTTP server on the board, prints handshake
# lines for the Qt client, runs for ~10 s, then tears everything down.
#
# Result codes:
#   SUC200  -> camera opened, server became ready, ran the full window cleanly
#   ERR200  -> any failure (no camera, missing deps, server never ready, etc.)

set -u

SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
PY_SERVER="$SCRIPT_DIR/camera_mjpeg_server.py"

DEVICE="${CAMERA_DEVICE:-25}"
PORT="${CAMERA_PORT:-8080}"
WIDTH="${CAMERA_WIDTH:-1280}"
HEIGHT="${CAMERA_HEIGHT:-720}"
FPS="${CAMERA_FPS:-30}"
QUALITY="${CAMERA_QUALITY:-75}"
DURATION="${CAMERA_DURATION:-10}"

LOG_FILE="/tmp/camera_mjpeg_server.log"
PID_FILE="/tmp/camera_mjpeg_server.pid"

CLIENT_PID=""
RESULT_PRINTED=0

print_result_once() {
    if [ "$RESULT_PRINTED" -eq 0 ]; then
        echo "$1"
        RESULT_PRINTED=1
    fi
}

cleanup() {
    if [ -n "$CLIENT_PID" ] && kill -0 "$CLIENT_PID" 2>/dev/null; then
        kill -TERM "$CLIENT_PID" 2>/dev/null || true
        for _ in 1 2 3 4 5; do
            kill -0 "$CLIENT_PID" 2>/dev/null || break
            sleep 0.2
        done
        kill -KILL "$CLIENT_PID" 2>/dev/null || true
    fi
    pkill -f "camera_mjpeg_server.py" 2>/dev/null || true
    rm -f "$PID_FILE"
}

on_exit() {
    status=$?
    cleanup
    if [ "$status" -ne 0 ]; then
        print_result_once "ERR200"
    fi
}

on_signal() {
    cleanup
    print_result_once "ERR200"
    trap - EXIT INT TERM
    exit 1
}

trap on_exit EXIT
trap on_signal INT TERM

fail() {
    echo "$*" >&2
    print_result_once "ERR200"
    exit 1
}

# --- Pre-flight checks -------------------------------------------------------
if [ ! -f "$PY_SERVER" ]; then
    fail "missing python server: $PY_SERVER"
fi

if ! command -v python3 >/dev/null 2>&1; then
    fail "python3 not found"
fi

if ! python3 -c "import cv2" >/dev/null 2>&1; then
    fail "python3 cv2 module not available"
fi

if ! command -v curl >/dev/null 2>&1; then
    fail "curl not found"
fi

# Stop any leftover instance from a previous run.
pkill -f "camera_mjpeg_server.py" 2>/dev/null || true
sleep 0.2

# --- Launch server -----------------------------------------------------------
: > "$LOG_FILE" || true
nohup python3 "$PY_SERVER" \
    --device "$DEVICE" \
    --port "$PORT" \
    --width "$WIDTH" \
    --height "$HEIGHT" \
    --fps "$FPS" \
    --quality "$QUALITY" \
    >"$LOG_FILE" 2>&1 &
CLIENT_PID=$!
echo "$CLIENT_PID" > "$PID_FILE"

# --- Wait for /healthz -------------------------------------------------------
READY=0
for _ in $(seq 1 25); do
    if ! kill -0 "$CLIENT_PID" 2>/dev/null; then
        break
    fi
    if curl -sf -m 1 "http://127.0.0.1:${PORT}/healthz" >/dev/null 2>&1; then
        READY=1
        break
    fi
    sleep 0.2
done

if [ "$READY" -ne 1 ]; then
    echo "----- server log -----" >&2
    tail -n 40 "$LOG_FILE" >&2 || true
    fail "MJPEG server failed to become ready on port $PORT"
fi

# --- Resolve eth0 IPv4 -------------------------------------------------------
BOARD_IP="$(ip -4 -o addr show eth0 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1)"
if [ -z "$BOARD_IP" ]; then
    BOARD_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
fi
if [ -z "$BOARD_IP" ]; then
    BOARD_IP="0.0.0.0"
fi

# --- Handshake for the Qt client --------------------------------------------
echo "BOARD_VIDEO_PORT=${PORT}"
echo "BOARD_VIDEO_PATH=/?action=stream"
echo "BOARD_IP=${BOARD_IP}"
echo "VIDEO_READY"

# --- Run for the configured window ------------------------------------------
ELAPSED=0
while [ "$ELAPSED" -lt "$DURATION" ]; do
    if ! kill -0 "$CLIENT_PID" 2>/dev/null; then
        echo "----- server log -----" >&2
        tail -n 40 "$LOG_FILE" >&2 || true
        fail "MJPEG server exited prematurely"
    fi
    sleep 1
    ELAPSED=$((ELAPSED + 1))
done

# --- Done --------------------------------------------------------------------
cleanup
trap - EXIT INT TERM
print_result_once "SUC200"
exit 0
