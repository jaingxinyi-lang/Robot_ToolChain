#!/bin/bash

echo "================================================"
echo "      RK3576 压测开始 （1分钟每项）"
echo "================================================"

apt update > /dev/null 2>&1
apt install stress -y > /dev/null 2>&1

# 初始化结果变量
RESULT="SUC100"

echo -e "\n===== CPU 压测 60秒 ====="
stress -c 8 -t 60
if [ $? -ne 0 ]; then
    RESULT="ERR100"
    echo "CPU 压测失败！"
fi

echo -e "\n===== 内存压测 60秒 ====="
stress -m 2 -t 60
if [ $? -ne 0 ]; then
    RESULT="ERR100"
    echo "内存压测失败！"
fi

echo -e "\n===== EMMC 压测 60秒 ====="
stress -d 2 -t 60
if [ $? -ne 0 ]; then
    RESULT="ERR100"
    echo "EMMC 压测失败！"
fi

echo -e "\n================================================"
echo "$RESULT"
echo "================================================"