#!/bin/sh

speak_wav_path="speak_test_stereo.wav"
mic_wav_path="mic_test.wav"

# 初始化测试结果
TEST_RESULT="SUC009"

echo "=== 开始回环测试 ==="

# 1. 先启动录音（后台运行）
echo "启动4通道录音..."
arecord --period-size=1024 --buffer-size=4096 \
        -r 16000 -c 4 -f s16_le -d 15 \
        $mic_wav_path 2>/dev/null &
RECORD_PID=$!

if [ $? -ne 0 ] || [ -z "$RECORD_PID" ]; then
    echo "ERROR: 录音启动失败"
    TEST_RESULT="ERR009"
fi

# 2. 等待录音缓冲区准备好
sleep 0.5

# 3. 播放测试音频（此时录音正在进行）
echo "播放测试音频: $speak_wav_path"
aplay $speak_wav_path 2>/dev/null
if [ $? -ne 0 ]; then
    echo "WARNING: 播放 $speak_wav_path 失败"
fi

sleep 1


# 4. 等待录音完成
echo "等待录音结束..."
wait $RECORD_PID
if [ $? -ne 0 ]; then
    echo "ERROR: 录音过程异常"
    TEST_RESULT="ERR009"
fi

# 5. 验证录音结果
echo "验证录音结果..."
if [ -f "$mic_wav_path" ]; then
    echo "播放录制结果..."
    aplay $mic_wav_path 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "ERROR: 播放录制结果失败"
        TEST_RESULT="ERR009"
    fi
else
    echo "ERROR: 录音文件不存在"
    TEST_RESULT="ERR009"
fi



# 7. 输出测试结果
echo "=== 测试完成 ==="
echo "$TEST_RESULT"
