#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PC_BIN="$SCRIPT_DIR/pc485_test"
RK_BIN="$SCRIPT_DIR/rk485_test"

if [ ! -x "$PC_BIN" ]; then
    echo "Error: $PC_BIN not found or not executable"
    exit 1
fi

if [ ! -x "$RK_BIN" ]; then
    echo "Error: $RK_BIN not found or not executable"
    exit 1
fi

# 启动 PC 端（后台运行，输出丢弃）
sudo "$PC_BIN" "$@" > /dev/null 2>&1 &
PC_PID=$!

# RK 端退出后，确保 PC 端一并退出
cleanup() {
    kill "$PC_PID" 2>/dev/null
    wait "$PC_PID" 2>/dev/null
}
trap cleanup EXIT

# 运行 RK 端（前台，输出到终端）
sudo "$RK_BIN"
