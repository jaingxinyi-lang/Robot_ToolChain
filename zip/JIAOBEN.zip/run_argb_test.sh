#!/bin/bash

# ==============================================================================
# ARGB LED 自动化测试脚本
# 运行环境: Linux (ARM64/x86_64)
# 测试目标: 验证ARGB LED灯可正常工作，能够按红-绿-蓝顺序循环显示
# 硬件需求: SPI设备 (/dev/spidev3.1), 6个ARGB LED灯
# 特点: 完全自动化，无需用户交互
# ==============================================================================

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${SCRIPT_DIR}"
BUILD_DIR="${PROJECT_DIR}/build"
TEST_APP="${BUILD_DIR}/argb_test"

# 测试配置
CYCLES=10
DELAY_MS=1000

echo -e "${CYAN}====================================================${NC}"
echo -e "${CYAN}        ARGB LED 自动化测试脚本                    ${NC}"
echo -e "${CYAN}====================================================${NC}\n"

# ------------------------------------------------------------------------------
# 阶段 1: 环境检查
# ------------------------------------------------------------------------------
echo -e "${GREEN}[阶段 1] 环境与依赖检查${NC}"

# 检查CMake
if ! command -v cmake &> /dev/null; then
    echo -e "${RED}错误: CMake未安装${NC}"
    echo "请安装CMake: sudo apt install cmake"
    exit 1
fi
echo -e "[✓] CMake已安装"

# 检查pkg-config
if ! command -v pkg-config &> /dev/null; then
    echo -e "${RED}错误: pkg-config未安装${NC}"
    echo "请安装pkg-config: sudo apt install pkg-config"
    exit 1
fi
echo -e "[✓] pkg-config已安装"

# 检查libgpiod
if ! pkg-config --exists libgpiod; then
    echo -e "${RED}错误: libgpiod未安装${NC}"
    echo "请安装libgpiod: sudo apt install libgpiod-dev"
    exit 1
fi
echo -e "[✓] libgpiod已安装"

echo ""

# ------------------------------------------------------------------------------
# 阶段 2: 编译项目
# ------------------------------------------------------------------------------
echo -e "${GREEN}[阶段 2] 编译ARGB测试程序${NC}"

# 创建构建目录
if [ ! -d "$BUILD_DIR" ]; then
    echo "创建构建目录: $BUILD_DIR"
    mkdir -p "$BUILD_DIR"
fi

# 进入构建目录
cd "$BUILD_DIR"

# 配置项目
echo "配置CMake项目..."
if ! cmake "$PROJECT_DIR"; then
    echo -e "${RED}CMake配置失败${NC}"
    exit 1
fi

# 编译项目
echo "编译ARGB测试程序..."
if ! make -j$(nproc); then
    echo -e "${RED}编译失败${NC}"
    exit 1
fi

echo -e "[✓] 编译完成"
echo ""

# ------------------------------------------------------------------------------
# 阶段 3: 硬件检查
# ------------------------------------------------------------------------------
echo -e "${GREEN}[阶段 3] 硬件检查${NC}"

# 检查测试程序是否存在
if [ ! -f "$TEST_APP" ]; then
    echo -e "${RED}错误: 测试程序不存在: $TEST_APP${NC}"
    exit 1
fi
echo -e "[✓] 测试程序已找到: $TEST_APP"

# 检查SPI设备是否存在
if [ ! -e "/dev/spidev3.1" ]; then
    echo -e "${RED}错误: SPI设备不存在: /dev/spidev3.1${NC}"
    echo "请确认:"
    echo "  1. SPI驱动已加载"
    echo "  2. 设备树配置正确"
    echo "  3. 硬件连接正常"
    exit 1
fi
echo -e "[✓] SPI设备已找到: /dev/spidev3.1"

echo ""

# ------------------------------------------------------------------------------
# 阶段 4: 自动测试配置
# ------------------------------------------------------------------------------
echo -e "${GREEN}[阶段 4] 自动测试配置${NC}"
echo "测试配置:"
echo "  - 循环次数: $CYCLES 次"
echo "  - 切换延迟: $DELAY_MS 毫秒"
echo "  - SPI设备: /dev/spidev3.1"
echo "  - LED数量: 6个"
echo ""

# 自动检查权限
echo "检查SPI设备权限..."
if [ ! -w "/dev/spidev3.1" ]; then
    echo -e "${YELLOW}警告: SPI设备权限不足，尝试自动修复...${NC}"
    if command -v sudo &> /dev/null; then
        sudo chmod 666 /dev/spidev3.1 2>/dev/null
        if [ $? -eq 0 ]; then
            echo -e "[✓] 权限修复成功"
        else
            echo -e "${RED}权限修复失败，请手动执行: sudo chmod 666 /dev/spidev3.1${NC}"
        fi
    fi
else
    echo -e "[✓] SPI设备权限正常"
fi

echo ""

# ------------------------------------------------------------------------------
# 阶段 5: 执行自动化测试
# ------------------------------------------------------------------------------
echo -e "${GREEN}[阶段 5] 执行ARGB LED自动化测试${NC}"
echo -e "${YELLOW}测试说明:${NC}"
echo "  - LED将按照 红 -> 绿 -> 蓝 的顺序循环显示"
echo "  - 每种颜色持续显示 ${DELAY_MS} 毫秒"
echo "  - 共有 6 个 ARGB LED灯同时变色"
echo "  - 循环 ${CYCLES} 次后自动结束"
echo ""

echo -e "${CYAN}>>> 启动自动化测试 (${CYCLES}次循环，${DELAY_MS}ms切换) <<<${NC}"
echo "--------------------------------------------------------"

# 执行测试程序
"$TEST_APP" -c "$CYCLES" -d "$DELAY_MS"
TEST_RESULT=$?

echo ""
echo "--------------------------------------------------------"

# ------------------------------------------------------------------------------
# 阶段 6: 自动结果评估
# ------------------------------------------------------------------------------
echo -e "${GREEN}[阶段 6] 自动结果评估${NC}"

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
LOG_FILE="${PROJECT_DIR}/argb_test_report.log"

# 根据退出码自动判断结果
if [ $TEST_RESULT -eq 0 ]; then
    echo -e "${GREEN}[✓] 测试程序正常退出${NC}"
    echo -e "${GREEN}结论: 测试通过 (SUC900)${NC}"
    echo -e "${GREEN}      ARGB LED功能正常，红绿蓝循环显示稳定。${NC}"
    echo "[$TIMESTAMP] ARGB LED自动化测试: SUC900 - 程序正常退出" >> "$LOG_FILE"
    FINAL_RESULT="SUC900"
elif [ $TEST_RESULT -eq 124 ]; then
    echo -e "${YELLOW}[!] 测试程序超时退出${NC}"
    echo -e "${YELLOW}结论: 测试部分通过 (ERR900)${NC}"
    echo "[$TIMESTAMP] ARGB LED自动化测试: ERR900 - 程序超时" >> "$LOG_FILE"
    FINAL_RESULT="ERR900"
else
    echo -e "${RED}[✗] 测试程序异常退出 (退出码: $TEST_RESULT)${NC}"
    echo -e "${RED}结论: 测试不通过 (FAIL)${NC}"
    echo "[$TIMESTAMP] ARGB LED自动化测试: FAIL - 退出码 $TEST_RESULT" >> "$LOG_FILE"
    FINAL_RESULT="FAIL"
fi

echo ""

# 生成详细报告
{
    echo "=========================================="
    echo "ARGB LED 自动化测试报告"
    echo "时间: $TIMESTAMP"
    echo "=========================================="
    echo "测试配置:"
    echo "  循环次数: $CYCLES"
    echo "  切换延迟: ${DELAY_MS}ms"
    echo "  SPI设备: /dev/spidev3.1"
    echo "  退出码: $TEST_RESULT"
    echo "  结果: $FINAL_RESULT"
    echo "------------------------------------------"
    echo "系统信息:"
    echo "  主机名: $(hostname)"
    echo "  系统: $(uname -s) $(uname -r)"
    echo "  架构: $(uname -m)"
    echo "=========================================="
    echo ""
} >> "$LOG_FILE"

echo -e "${YELLOW}详细日志已保存至: $LOG_FILE${NC}"
echo ""

# 返回项目目录
cd "$PROJECT_DIR"

# 最终结果输出
echo -e "${CYAN}====================================================${NC}"
if [ "$FINAL_RESULT" = "SUC900" ]; then
    echo -e "${CYAN}               ${GREEN}SUC900${CYAN}                         ${NC}"
elif [ "$FINAL_RESULT" = "ERR900" ]; then
    echo -e "${CYAN}               ${YELLOW}ERR900${CYAN}                      ${NC}"
else
    echo -e "${CYAN}               ${RED}FAIL${CYAN}                          ${NC}"
fi
echo -e "${CYAN}====================================================${NC}\n"

# 退出码
if [ "$FINAL_RESULT" = "SUC900" ]; then
    exit 0
else
    exit 1
fi