#!/bin/bash

# ==================== 配置参数 ====================
PC_IP="192.168.22.42"  # 写死的PC IP地址
TEST_TIME=20
THREAD_NUM=4

SPEED_MIN=500
LOSS_MAX=0.1
FLUC_MAX=50

# 颜色变量清空
RED=""
GREEN=""
YELLOW=""
NONE=""

# ==================== 函数定义 ====================
check_iperf3() {
    if ! which iperf3 &> /dev/null; then
        echo "[警告] iperf3 未安装，正在自动安装..."
        export DEBIAN_FRONTEND=noninteractive
        sudo -E apt-get update -y
        sudo -E apt-get install iperf3 -y
        if [ $? -ne 0 ]; then
            echo "[错误] iperf3 安装失败，请手动安装"
            echo "ERR1000"
            exit 1
        fi
        echo "[成功] iperf3 安装完成"
        echo "SUC1000"
        echo
    fi
}

check_bc() {
    if ! which bc &> /dev/null; then
        echo "[警告] bc 计算工具未安装，正在自动安装..."
        export DEBIAN_FRONTEND=noninteractive
        sudo -E apt-get install bc -y
        if [ $? -ne 0 ]; then
            echo "[错误] bc 安装失败"
            echo "ERR1000"
            exit 1
        fi
        echo "[成功] bc 安装完成"
        echo "SUC1000"
        echo
    fi
}

check_param() {
    if [ -z "$PC_IP" ]; then
        echo "[错误] PC IP未配置"
        echo "ERR1000"
        exit 1
    fi
    echo "[INFO] 已读取PC服务端IP：$PC_IP"
    echo "SUC1000"
}

get_rk3576_ip() {
    local ip=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    
    if [ -z "$ip" ]; then
        ip=$(ip addr show wlp2s0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    fi
    if [ -z "$ip" ]; then
        ip=$(ip addr show wlan1 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    fi
    
    echo "$ip"
}

check_internet() {
    echo
    echo "============ 互联网连接检测 ============"
    echo "[检测] 正在 ping www.baidu.com ..."
    
    local ping_result=$(timeout 5 ping -c 2 -W 2 www.baidu.com 2>&1)
    local ping_status=$?
    
    if [ $ping_status -eq 0 ]; then
        local avg_latency=$(echo "$ping_result" | tail -1 | awk -F '/' '{print $5}')
        echo "[结果] 互联网连接正常"
        echo "[信息] 平均延迟：${avg_latency} ms"
        echo "SUC1000"
    else
        echo "[警告] 无法连接互联网（不影响局域网测速）"
        echo "SUC1000"
    fi
    echo "========================================"
    echo
}

wait_for_network() {
    echo "[等待] RK3576 获取WiFi IP..."
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        LOCAL_IP=$(get_rk3576_ip)
        
        if [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "127.0.0.1" ]; then
            if [[ $LOCAL_IP =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                echo "[检测] RK3576 IP: $LOCAL_IP"
                echo "SUC1000"
                break
            fi
        fi
        sleep 2
        ((attempt++))
    done
    
    if [ $attempt -ge $max_attempts ]; then
        echo "[错误] WiFi IP 获取失败，请检查WiFi连接"
        echo "ERR1000"
        exit 1
    fi

    echo "[等待] 测试与PC $PC_IP 的连接..."
    local ping_attempts=0
    local max_ping_attempts=30
    
    while [ $ping_attempts -lt $max_ping_attempts ]; do
        if ping -c 3 -W 2 $PC_IP &> /dev/null; then
            echo "[检测] 网络连接正常，可以与PC通信"
            echo "SUC1000"
            
            local subnet=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}')
            if [ -n "$subnet" ]; then
                echo "[信息] RK3576网络配置：$subnet"
            fi
            
            break
        fi
        sleep 2
        ((ping_attempts++))
    done
    
    if [ $ping_attempts -ge $max_ping_attempts ]; then
        echo "[错误] 无法ping通PC $PC_IP，请检查网络配置"
        echo "[提示] RK3576 IP: $LOCAL_IP"
        echo "[提示] PC IP: $PC_IP"
        echo "[提示] 请确保两者在同一网络或路由可达"
        echo "ERR1000"
        exit 1
    fi
}

wait_for_iperf_server() {
    echo "[等待] iperf3 服务..."
    local max_attempts=15
    local attempt=0
    while [ $attempt -lt $max_attempts ]; do
        timeout 2 bash -c "echo >/dev/tcp/$PC_IP/5201" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "[检测] iperf3 服务正常"
            echo "SUC1000"
            return 0
        fi
        sleep 2
        ((attempt++))
    done
    echo "[错误] iperf3 服务未启动"
    echo "ERR1000"
    exit 1
}

parse_and_check() {
    local log="$1"
    local title="$2"

    echo "================================================================"
    echo "                    $title"
    echo "================================================================"

    AVG_SPEED=$(grep 'sender' "$log" | tail -n1 | grep -oP '[\d.]+(?=\s+Mbits/sec)')
    
    SPEEDS=$(grep -P '\d+\.\d+-\d+\.\d+\s+sec' "$log" | grep -v 'receiver' | grep -oP '[\d.]+(?=\s+Mbits/sec)')
    
    MIN_SPEED=0
    MAX_SPEED=0
    FLUCTUATION=0
    if [ -n "$SPEEDS" ]; then
        MIN_SPEED=$(echo "$SPEEDS" | sort -n | head -n1)
        MAX_SPEED=$(echo "$SPEEDS" | sort -n | tail -n1)
        FLUCTUATION=$(echo "$MAX_SPEED - $MIN_SPEED" | bc 2>/dev/null)
    fi

    LOSS_RATE=$(grep -oP '[\d.]+(?=\%)' "$log" | head -n1)
    LOSS_RATE=${LOSS_RATE:-0.0}
    AVG_SPEED=${AVG_SPEED:-0.0}
    FLUCTUATION=${FLUCTUATION:-0.0}

    echo "PC IP         ：$PC_IP"
    echo "本机IP        ：$LOCAL_IP"
    echo "平均速率      ：${AVG_SPEED} Mbps  (≥ ${SPEED_MIN})"
    echo "速率波动      ：${FLUCTUATION} Mbps  (≤ ${FLUC_MAX})"
    echo "丢包率        ：${LOSS_RATE} %  (≤ ${LOSS_MAX})"
    echo "----------------------------------------------------------------"

    local test_pass=0
    if (( $(echo "$AVG_SPEED >= $SPEED_MIN" | bc -l) )); then
        echo "速率状态：合格"
    else
        echo "速率状态：不合格"
        test_pass=1
    fi
    if (( $(echo "$FLUCTUATION <= $FLUC_MAX" | bc -l) )); then
        echo "波动状态：合格"
    else
        echo "波动状态：不合格"
        test_pass=1
    fi
    if (( $(echo "$LOSS_RATE <= $LOSS_MAX" | bc -l) )); then
        echo "丢包状态：合格"
    else
        echo "丢包状态：不合格"
        test_pass=1
    fi

    echo "================================================================"
    if [ $test_pass -eq 0 ]; then
        echo "当前测试结果：SUC1000"
        return 0
    else
        echo "当前测试结果：ERR1000"
        return 1
    fi
}

# ==================== 主流程 ====================
check_param
check_iperf3
check_bc
wait_for_network

check_internet

wait_for_iperf_server

echo
echo "==================== 【1/2】上行测试 ===================="
echo

iperf3 -c $PC_IP -t $TEST_TIME -P $THREAD_NUM -f m > tmp_up.log
UP_RESULT=$?
parse_and_check tmp_up.log "上行测试 RK3576 -> PC"
UP_TEST_PASS=$?

echo
echo "==================== 【2/2】下行测试 ===================="
echo

iperf3 -c $PC_IP -t $TEST_TIME -P $THREAD_NUM -f m -R > tmp_dn.log
DOWN_RESULT=$?
parse_and_check tmp_dn.log "下行测试 PC -> RK3576"
DOWN_TEST_PASS=$?

rm -f tmp_up.log tmp_dn.log

echo
echo "==================== 双向WiFi测速全部完成 ===================="
echo "================================================================"

if [ $UP_TEST_PASS -eq 0 ] && [ $DOWN_TEST_PASS -eq 0 ]; then
    echo "最终测试结果：SUC1000"
else
    echo "最终测试结果：ERR1000"
fi
echo "================================================================"
exit 0