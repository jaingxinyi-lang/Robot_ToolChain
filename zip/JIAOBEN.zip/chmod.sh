#!/bin/bash
chmod +x /home/noetix/JIAOBEN/*.sh