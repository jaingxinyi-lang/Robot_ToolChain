#!/bin/sh

speak_wav_path="speak_test_stereo.wav"  #播放音频文件
mic_wav_path="mic_test.wav" #录制文件

# 初始化测试结果
TEST_RESULT="SUC600"
RECORD_PID=""

# 定义清理函数
cleanup() {
    if [ -n "$RECORD_PID" ] && kill -0 "$RECORD_PID" 2>/dev/null; then
        echo "强制终止录音进程 (PID: $RECORD_PID)..."
        kill -9 "$RECORD_PID" 2>/dev/null
        wait "$RECORD_PID" 2>/dev/null
    fi
}

# 设置退出时的清理陷阱
trap cleanup EXIT INT TERM

echo "=== 开始回环测试 ==="

# 1. 先启动录音（后台运行）
echo "启动4通道录音..."
arecord --period-size=1024 --buffer-size=4096 \
        -r 16000 -c 4 -f s16_le -d 15 \
        "$mic_wav_path" 2>/dev/null &
RECORD_PID=$!

if [ $? -ne 0 ] || [ -z "$RECORD_PID" ]; then
    echo "ERROR: 录音启动失败"
    TEST_RESULT="ERR600"
    cleanup
    exit 1
fi

echo "录音进程已启动 (PID: $RECORD_PID)"

# 2. 等待录音缓冲区准备好
sleep 0.5

# 3. 播放测试音频（此时录音正在进行）
echo "播放测试音频(只有左通道): $speak_wav_path"
if [ -f "$speak_wav_path" ]; then
    sox "$speak_wav_path" -t wav - remix 1 2>/dev/null | aplay -c 1 -q 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "WARNING: 播放 $speak_wav_path 失败"
    fi
else
    echo "WARNING: 文件不存在: $speak_wav_path"
fi

sleep 1


# 4. 等待录音完成（使用轮询方式）
echo "等待录音结束（最多等待 20 秒）..."

WAIT_COUNT=0
MAX_WAIT=20
RECORD_TIMEOUT=false

while kill -0 "$RECORD_PID" 2>/dev/null; do
    sleep 1
    WAIT_COUNT=$((WAIT_COUNT + 1))
    
    if [ $WAIT_COUNT -ge $MAX_WAIT ]; then
        echo "ERROR: 录音超时未结束（已等待 ${WAIT_COUNT} 秒）"
        RECORD_TIMEOUT=true
        cleanup
        break
    fi
    
    # 每 5 秒输出一次进度
    if [ $((WAIT_COUNT % 5)) -eq 0 ]; then
        echo "已等待 ${WAIT_COUNT} 秒..."
    fi
done

if [ "$RECORD_TIMEOUT" = true ]; then
    TEST_RESULT="ERR600"
    RECORD_PID=""
else
    echo "录音正常结束（耗时 ${WAIT_COUNT} 秒）"
    # 获取录音进程的退出状态
    wait "$RECORD_PID"
    RECORD_EXIT_CODE=$?
    if [ $RECORD_EXIT_CODE -ne 0 ]; then
        echo "WARNING: 录音进程退出码: $RECORD_EXIT_CODE"
    fi
fi

# 清除 PID 变量，防止 cleanup 重复清理
RECORD_PID=""

# 5. 验证录音结果
echo "验证录音结果..."
if [ -f "$mic_wav_path" ]; then
    # 检查文件大小，确保不是空文件
    FILE_SIZE=$(stat -c%s "$mic_wav_path" 2>/dev/null || stat -f%z "$mic_wav_path" 2>/dev/null || echo "0")
    if [ "$FILE_SIZE" -gt 44 ]; then  # WAV 文件头至少 44 字节
        echo "录音文件大小: $FILE_SIZE 字节"
        
        echo "播放录制结果..."
        aplay "$mic_wav_path" 2>/dev/null
        if [ $? -ne 0 ]; then
            echo "ERROR: 播放录制结果失败"
            TEST_RESULT="ERR600"
        fi
    else
        echo "ERROR: 录音文件过小（可能无效）: $FILE_SIZE 字节"
        TEST_RESULT="ERR600"
    fi
else
    echo "ERROR: 录音文件不存在: $mic_wav_path"
    TEST_RESULT="ERR600"
fi


# 7. 输出测试结果
echo "=== 测试完成 ==="
echo " $TEST_RESULT"
