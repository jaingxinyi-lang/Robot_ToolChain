# -*- coding: utf-8 -*-
"""Minimal MJPEG over HTTP server for Robot_ToolChain camera test.

Provides:
  GET /healthz             -> 200 OK plain text
  GET /?action=stream      -> multipart/x-mixed-replace MJPEG stream
  GET /?action=snapshot    -> single JPEG frame

Compatible with mjpg-streamer URL convention so the Qt client can reuse one
parser. The process exits with non-zero status if the camera cannot be opened.
"""

from __future__ import annotations

import argparse
import signal
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import cv2


_BOUNDARY = "frame"


class FrameGrabber:
    def __init__(self, device, width, height, fps):
        self._device = device
        self._width = width
        self._height = height
        self._fps = fps
        self._cap = None
        self._frame = None
        self._lock = threading.Lock()
        self._stop_evt = threading.Event()
        self._thread = None

    def open(self):
        # Allow integer index or string device path.
        try:
            dev = int(self._device)
        except (TypeError, ValueError):
            dev = self._device

        # 在嵌入式板上优先使用 V4L2 后端，绕过 GStreamer 流水线无法查询流位置的警告
        cap = None
        for backend in (cv2.CAP_V4L2, cv2.CAP_ANY):
            try:
                c = cv2.VideoCapture(dev, backend)
            except Exception:
                continue
            if c.isOpened():
                cap = c
                break
            c.release()
        if cap is None or not cap.isOpened():
            return False

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._height)
        cap.set(cv2.CAP_PROP_FPS, self._fps)

        # 部分摄像头需要预热帧才能正常读取，最多重试 30 次（总计 ~3 s）
        ok, frame = False, None
        for _ in range(30):
            ok, frame = cap.read()
            if ok and frame is not None:
                break
            time.sleep(0.1)

        if not ok or frame is None:
            cap.release()
            return False
        with self._lock:
            self._frame = frame
        self._cap = cap
        return True

    def start(self):
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_evt.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        if self._cap is not None:
            self._cap.release()
            self._cap = None

    def latest(self):
        with self._lock:
            return self._frame

    def _loop(self):
        period = 1.0 / max(self._fps, 1)
        while not self._stop_evt.is_set():
            t0 = time.time()
            ok, frame = self._cap.read()
            if not ok or frame is None:
                # transient read failure; brief backoff
                time.sleep(0.02)
                continue
            with self._lock:
                self._frame = frame
            elapsed = time.time() - t0
            if elapsed < period:
                time.sleep(period - elapsed)


class MjpegHandler(BaseHTTPRequestHandler):
    grabber: "FrameGrabber" = None  # injected by main()
    jpeg_quality: int = 75

    # Silence default access logging.
    def log_message(self, format, *args):  # noqa: A002
        return

    def _encode(self, frame):
        ok, buf = cv2.imencode(
            ".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality]
        )
        if not ok:
            return None
        return buf.tobytes()

    def do_GET(self):  # noqa: N802
        path = self.path or "/"
        if path.startswith("/healthz"):
            self._serve_healthz()
            return
        if "action=snapshot" in path:
            self._serve_snapshot()
            return
        # Default to MJPEG stream for any other path; matches mjpg-streamer's
        # /?action=stream endpoint and friendlier defaults.
        self._serve_stream()

    def _serve_healthz(self):
        body = b"OK"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _serve_snapshot(self):
        frame = self.grabber.latest()
        if frame is None:
            self.send_error(503, "Camera not ready")
            return
        data = self._encode(frame)
        if data is None:
            self.send_error(500, "Encode failed")
            return
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _serve_stream(self):
        self.send_response(200)
        self.send_header("Cache-Control", "no-cache, private")
        self.send_header("Pragma", "no-cache")
        self.send_header(
            "Content-Type",
            "multipart/x-mixed-replace; boundary=" + _BOUNDARY,
        )
        self.end_headers()

        period = 1.0 / 30.0
        try:
            while True:
                frame = self.grabber.latest()
                if frame is None:
                    time.sleep(0.01)
                    continue
                data = self._encode(frame)
                if data is None:
                    time.sleep(0.01)
                    continue
                header = (
                    "--" + _BOUNDARY + "\r\n"
                    "Content-Type: image/jpeg\r\n"
                    "Content-Length: " + str(len(data)) + "\r\n\r\n"
                )
                self.wfile.write(header.encode("ascii"))
                self.wfile.write(data)
                self.wfile.write(b"\r\n")
                self.wfile.flush()
                time.sleep(period)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            return
        except OSError:
            return


class _DualStackServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def server_bind(self):
        # Bind explicitly to IPv4 0.0.0.0 to keep behaviour predictable.
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        ThreadingHTTPServer.server_bind(self)


def _parse_args(argv):
    parser = argparse.ArgumentParser(description="Minimal MJPEG HTTP server")
    parser.add_argument("--device", default="25",
                        help="Camera device index or path (default: 25)")
    parser.add_argument("--port", type=int, default=8080,
                        help="HTTP listen port (default: 8080)")
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--quality", type=int, default=75,
                        help="JPEG quality 1-100 (default: 75)")
    return parser.parse_args(argv)


def main(argv=None):
    args = _parse_args(argv)
    grabber = FrameGrabber(args.device, args.width, args.height, args.fps)
    if not grabber.open():
        sys.stderr.write("camera open failed: device=%s\n" % str(args.device))
        return 2
    grabber.start()

    MjpegHandler.grabber = grabber
    MjpegHandler.jpeg_quality = max(1, min(100, args.quality))

    server = _DualStackServer(("0.0.0.0", args.port), MjpegHandler)

    stop_evt = threading.Event()

    def _on_signal(_signum, _frame):
        stop_evt.set()
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, _on_signal)
    signal.signal(signal.SIGINT, _on_signal)

    sys.stdout.write("MJPEG server listening on 0.0.0.0:%d\n" % args.port)
    sys.stdout.flush()

    try:
        server.serve_forever(poll_interval=0.2)
    finally:
        try:
            server.server_close()
        except Exception:
            pass
        grabber.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
