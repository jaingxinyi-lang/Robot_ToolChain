#!/bin/bash

set -e

# ============================================
# 网络配置脚本 - 双网口IP配置
# 功能：配置end0和enp1s0两个网络接口
# 成功输出: SUC001
# 失败输出: ERR001
# ============================================

RED=''
GREEN=''
YELLOW=''
NC=''

TEST_STATUS=0

set_failed() {
    TEST_STATUS=1
}

print_result() {
    echo ""
    echo "================================================"
    if [ $TEST_STATUS -eq 0 ]; then
        echo "  网络配置成功"
        echo "  SUC001"
    else
        echo "  网络配置失败"
        echo "  ERR001"
    fi
    echo "================================================"
}

echo "================================================"
echo "  网络配置脚本 - 双网口IP配置"
echo "================================================"
echo ""

# ============================================
# 禁用 NetworkManager 对目标接口的管理
# ============================================
echo "================================================"
echo "  禁用 NetworkManager 自动管理"
echo "================================================"

for IFACE in end0 enp1s0; do
    echo "设置 $IFACE 为未托管..."
    if command -v nmcli >/dev/null 2>&1; then
        CONN=$(nmcli -t -f NAME,DEVICE connection show 2>/dev/null | grep ":$IFACE$" | cut -d: -f1)
        if [ -n "$CONN" ]; then
            sudo nmcli connection down "$CONN" 2>/dev/null
            echo "[OK] 已断开连接: $CONN"
        fi
        sudo nmcli device set "$IFACE" managed no 2>/dev/null
        echo "[OK] $IFACE 已设为未托管"
    else
        echo "[警告] nmcli 不可用，跳过"
    fi
done

echo ""

# ============================================
# 配置 end0 网络接口
# ============================================
echo "================================================"
echo "  配置 end0 网络接口"
echo "================================================"
echo "  IP地址: 192.168.56.102/24"
echo "  广播地址: 192.168.56.255"
echo ""

if ip link show end0 >/dev/null 2>&1; then
    echo "[OK] end0 接口存在"
else
    echo "[ERROR] end0 接口不存在"
    set_failed
    print_result
    exit 1
fi

echo "清除 end0 现有配置..."
sudo ip addr flush dev end0 2>/dev/null || {
    echo "[警告] 清除 end0 配置时出现问题"
}

echo "配置 end0 IP地址..."
if sudo ip addr add 192.168.56.102/24 broadcast 192.168.56.255 dev end0 2>/dev/null; then
    echo "[OK] end0 IP地址配置成功"
else
    echo "[ERROR] end0 IP地址配置失败"
    set_failed
    print_result
    exit 1
fi

echo "启用 end0 接口..."
if sudo ip link set end0 up 2>/dev/null; then
    echo "[OK] end0 接口已启用"
else
    echo "[ERROR] 启用 end0 接口失败"
    set_failed
    print_result
    exit 1
fi

END0_IP=$(ip addr show end0 2>/dev/null | grep -oP 'inet \K[\d.]+' | head -1)
if [ "$END0_IP" = "192.168.56.102" ]; then
    echo "[验证] end0 配置正确: $END0_IP"
else
    echo "[ERROR] end0 配置验证失败，当前IP: ${END0_IP:-无}"
    set_failed
fi

echo ""

# ============================================
# 配置 enp1s0 网络接口
# ============================================
echo "================================================"
echo "  配置 enp1s0 网络接口"
echo "================================================"
echo "  IP地址: 192.168.57.102/24"
echo "  广播地址: 192.168.57.255"
echo ""

if ip link show enp1s0 >/dev/null 2>&1; then
    echo "[OK] enp1s0 接口存在"
else
    echo "[ERROR] enp1s0 接口不存在"
    set_failed
    print_result
    exit 1
fi

echo "清除 enp1s0 现有配置..."
sudo ip addr flush dev enp1s0 2>/dev/null || {
    echo "[警告] 清除 enp1s0 配置时出现问题"
}

echo "配置 enp1s0 IP地址..."
if sudo ip addr add 192.168.57.102/24 broadcast 192.168.57.255 dev enp1s0 2>/dev/null; then
    echo "[OK] enp1s0 IP地址配置成功"
else
    echo "[ERROR] enp1s0 IP地址配置失败"
    set_failed
    print_result
    exit 1
fi

echo "启用 enp1s0 接口..."
if sudo ip link set enp1s0 up 2>/dev/null; then
    echo "[OK] enp1s0 接口已启用"
else
    echo "[ERROR] 启用 enp1s0 接口失败"
    set_failed
    print_result
    exit 1
fi

ENP1S0_IP=$(ip addr show enp1s0 2>/dev/null | grep -oP 'inet \K[\d.]+' | head -1)
if [ "$ENP1S0_IP" = "192.168.57.102" ]; then
    echo "[验证] enp1s0 配置正确: $ENP1S0_IP"
else
    echo "[ERROR] enp1s0 配置验证失败，当前IP: ${ENP1S0_IP:-无}"
    set_failed
fi

echo ""

# ============================================
# 配置总结
# ============================================
echo "================================================"
echo "  网络配置总结"
echo "================================================"

echo "end0 接口状态:"
if ip addr show end0 2>/dev/null | grep -q "inet "; then
    ip addr show end0 | grep -E "inet |state" | sed 's/^/  /'
    echo "  [状态] 配置成功"
else
    echo "  [状态] 未获取到IP地址"
    set_failed
fi

echo ""

echo "enp1s0 接口状态:"
if ip addr show enp1s0 2>/dev/null | grep -q "inet "; then
    ip addr show enp1s0 | grep -E "inet |state" | sed 's/^/  /'
    echo "  [状态] 配置成功"
else
    echo "  [状态] 未获取到IP地址"
    set_failed
fi

echo ""

print_result

if [ $TEST_STATUS -eq 0 ]; then
    exit 0
else
    exit 1
fi