#!/bin/bash

# USB3.0 读写速率测试脚本
# 测试 U盘 -> 板子（下载）和 板子 -> U盘（上传）的速率

# 颜色变量清空
RED=''
GREEN=''
YELLOW=''
NC=''

# 测试状态标志
TEST_STATUS=0  # 0=成功, 1=失败

if [ "$EUID" -ne 0 ]; then
    echo "[INFO] 需要root权限，正在获取sudo..."
    exec sudo "$0" "$@"
    exit $?
fi

# 配置参数
USB_DEVICE="/dev/sda1"      # U盘设备
USB_MOUNT_POINT="/media/usb" # U盘挂载点
TEST_FILE="111/test_1gb.bin"  # U盘上的测试文件路径
UPLOAD_DIR="222"            # 上传到U盘的目标文件夹
LOCAL_DOWNLOAD_PATH="/tmp/usb_test_download.bin"  # 下载到板子的临时路径
LOCAL_UPLOAD_FILE=""        # 上传用的临时文件
MIN_FREE_SPACE_MB=2048      # 最小可用空间要求（MB），默认2GB

echo "========================================"
echo "    USB3.0 读写速率测试工具"
echo "========================================"
echo ""

# 函数：设置失败状态
set_failed() {
    TEST_STATUS=1
}

# 函数：输出最终结果
print_final_result() {
    echo ""
    echo "========================================"
    if [ $TEST_STATUS -eq 0 ]; then
        echo "    SUC008"
    else
        echo "    ERR008"
    fi
    echo "========================================"
}

# 函数：清理板子内存
cleanup_board_memory() {
    echo "[INFO] 清理板子临时文件..."
    
    # 清理下载测试文件
    if [ -f "$LOCAL_DOWNLOAD_PATH" ]; then
        rm -f "$LOCAL_DOWNLOAD_PATH"
        echo "[OK] 已删除板子上的下载文件: $LOCAL_DOWNLOAD_PATH"
    fi
    
    # 清理/tmp目录下的测试文件（根据模式匹配）
    rm -f /tmp/usb_test_*.bin 2>/dev/null
    rm -f /tmp/test_*.bin 2>/dev/null
    
    # 清理系统缓存以释放内存
    sync
    echo 3 > /proc/sys/vm/drop_caches 2>/dev/null && echo "[OK] 已清理系统缓存" || true
    
    echo "[OK] 板子内存清理完成"
    echo ""
}

# 函数：检查板子磁盘空间
check_board_space() {
    echo "[INFO] 检查板子磁盘空间..."
    
    # 获取/tmp所在分区的可用空间
    AVAILABLE_SPACE=$(df -m /tmp | tail -1 | awk '{print $4}')
    AVAILABLE_SPACE_GB=$(echo "scale=2; $AVAILABLE_SPACE / 1024" | bc 2>/dev/null)
    
    echo "[INFO] /tmp 可用空间: ${AVAILABLE_SPACE}MB (${AVAILABLE_SPACE_GB}GB)"
    
    if [ "$AVAILABLE_SPACE" -lt "$MIN_FREE_SPACE_MB" ]; then
        echo "[WARNING] 可用空间不足 ${MIN_FREE_SPACE_MB}MB！"
        echo "[INFO] 尝试清理空间..."
        cleanup_board_memory
        
        # 重新检查空间
        AVAILABLE_SPACE=$(df -m /tmp | tail -1 | awk '{print $4}')
        if [ "$AVAILABLE_SPACE" -lt "$MIN_FREE_SPACE_MB" ]; then
            echo "[ERROR] 清理后空间仍不足！"
            echo "请手动清理 /tmp 目录或扩展存储空间"
            echo ""
            echo "当前/tmp目录大文件："
            find /tmp -type f -size +100M -exec ls -lh {} \; 2>/dev/null | head -10
            set_failed
            print_final_result
            exit 1
        else
            echo "[OK] 清理后可用空间: ${AVAILABLE_SPACE}MB"
        fi
    else
        echo "[OK] 磁盘空间充足"
    fi
    echo ""
}

# 函数：挂载U盘
mount_usb() {
    echo "[INFO] 检查U盘挂载状态..."
    
    # 检查设备是否存在
    if [ ! -b "$USB_DEVICE" ]; then
        echo "[ERROR] 未检测到U盘设备: $USB_DEVICE"
        echo "请插入U盘后重试"
        echo ""
        echo "当前块设备："
        lsblk
        set_failed
        print_final_result
        exit 1
    fi
    
    # 检查是否已经挂载
    if mount | grep -q "$USB_DEVICE"; then
        USB_MOUNT_POINT=$(mount | grep "$USB_DEVICE" | awk '{print $3}')
        echo "[OK] U盘已挂载: $USB_MOUNT_POINT"
    else
        echo "[INFO] U盘未挂载，正在挂载..."
        
        # 创建挂载点
        if [ ! -d "$USB_MOUNT_POINT" ]; then
            mkdir -p "$USB_MOUNT_POINT"
        fi
        
        # 挂载U盘
        mount "$USB_DEVICE" "$USB_MOUNT_POINT"
        
        if [ $? -eq 0 ]; then
            echo "[OK] U盘挂载成功: $USB_MOUNT_POINT"
        else
            echo "[ERROR] U盘挂载失败"
            set_failed
            print_final_result
            exit 1
        fi
    fi
    echo ""
}

# 函数：检查文件是否存在
check_files() {
    echo "[INFO] 检查测试文件..."
    
    if [ ! -f "$USB_MOUNT_POINT/$TEST_FILE" ]; then
        echo "[ERROR] 测试文件不存在: $USB_MOUNT_POINT/$TEST_FILE"
        echo "请确保U盘根目录下有 '111' 文件夹，里面有 'test_1gb.bin' 文件"
        echo "U盘目录内容："
        ls -la "$USB_MOUNT_POINT/" 2>/dev/null
        set_failed
        print_final_result
        exit 1
    fi
    
    echo "[OK] 找到测试文件: $USB_MOUNT_POINT/$TEST_FILE"
    echo ""
}

# 函数：创建上传目录
create_upload_dir() {
    if [ ! -d "$USB_MOUNT_POINT/$UPLOAD_DIR" ]; then
        echo "[INFO] 创建上传目录: $USB_MOUNT_POINT/$UPLOAD_DIR"
        mkdir -p "$USB_MOUNT_POINT/$UPLOAD_DIR"
    fi
    echo "[OK] 上传目录已准备: $USB_MOUNT_POINT/$UPLOAD_DIR"
    echo ""
}

# 函数：测试下载速度（U盘 -> 板子）
test_download_speed() {
    echo "========================================"
    echo "    测试1: 下载速度 (U盘 -> RK3576)"
    echo "========================================"
    
    # 清理旧文件
    rm -f "$LOCAL_DOWNLOAD_PATH"
    
    # 获取文件大小
    FILE_SIZE=$(stat -c%s "$USB_MOUNT_POINT/$TEST_FILE" 2>/dev/null)
    FILE_SIZE_MB=$(echo "scale=2; $FILE_SIZE / 1048576" | bc 2>/dev/null || echo "0")
    
    echo "[INFO] 开始下载测试，文件大小: ${FILE_SIZE_MB}MB"
    echo "[INFO] 源文件: $USB_MOUNT_POINT/$TEST_FILE"
    echo "[INFO] 目标位置: $LOCAL_DOWNLOAD_PATH"
    echo ""
    
    # 测试下载速度
    START_TIME=$(date +%s.%N)
    dd if="$USB_MOUNT_POINT/$TEST_FILE" of="$LOCAL_DOWNLOAD_PATH" bs=4M status=progress 2>&1
    DD_EXIT_CODE=$?
    END_TIME=$(date +%s.%N)
    
    # 检查dd命令是否成功
    if [ $DD_EXIT_CODE -ne 0 ]; then
        echo "[ERROR] 下载测试失败（dd命令执行异常）"
        set_failed
        return 1
    fi
    
    # 检查文件是否完整
    SOURCE_SIZE=$(stat -c%s "$USB_MOUNT_POINT/$TEST_FILE" 2>/dev/null)
    DEST_SIZE=$(stat -c%s "$LOCAL_DOWNLOAD_PATH" 2>/dev/null)
    
    if [ "$SOURCE_SIZE" != "$DEST_SIZE" ]; then
        echo "[ERROR] 下载文件不完整（源: $SOURCE_SIZE bytes, 目标: $DEST_SIZE bytes）"
        set_failed
        return 1
    fi
    
    # 计算速度
    TIME_DIFF=$(echo "$END_TIME - $START_TIME" | bc)
    if [ "$TIME_DIFF" != "0" ]; then
        SPEED_MB=$(echo "scale=2; $FILE_SIZE / 1048576 / $TIME_DIFF" | bc)
        echo ""
        echo "[RESULT] 下载文件大小: ${FILE_SIZE_MB} MB"
        echo "[RESULT] 下载耗时: ${TIME_DIFF} 秒"
        echo "[RESULT] 下载速度: ${SPEED_MB} MB/s"
    else
        echo "[ERROR] 下载时间计算异常"
        set_failed
        return 1
    fi
    
    sync
    echo ""
    
    # 保存下载文件路径用于后续上传测试
    LOCAL_UPLOAD_FILE="$LOCAL_DOWNLOAD_PATH"
    echo "[OK] 下载测试完成，文件已保存到板子"
    echo ""
}

# 函数：测试上传速度（板子 -> U盘）
test_upload_speed() {
    echo "========================================"
    echo "    测试2: 上传速度 (RK3576 -> U盘)"
    echo "========================================"
    
    UPLOAD_PATH="$USB_MOUNT_POINT/$UPLOAD_DIR/test_upload.bin"
    
    echo "[INFO] 开始上传测试..."
    echo "[INFO] 源文件: $LOCAL_UPLOAD_FILE"
    echo "[INFO] 目标位置: $UPLOAD_PATH"
    echo ""
    
    # 检查源文件是否存在
    if [ ! -f "$LOCAL_UPLOAD_FILE" ]; then
        echo "[ERROR] 源文件不存在: $LOCAL_UPLOAD_FILE"
        set_failed
        return 1
    fi
    
    # 获取文件大小
    FILE_SIZE=$(stat -c%s "$LOCAL_UPLOAD_FILE" 2>/dev/null)
    FILE_SIZE_MB=$(echo "scale=2; $FILE_SIZE / 1048576" | bc 2>/dev/null || echo "0")
    
    # 测试上传
    START_TIME=$(date +%s.%N)
    dd if="$LOCAL_UPLOAD_FILE" of="$UPLOAD_PATH" bs=4M status=progress 2>&1
    DD_EXIT_CODE=$?
    END_TIME=$(date +%s.%N)
    
    # 检查dd命令是否成功
    if [ $DD_EXIT_CODE -ne 0 ]; then
        echo "[ERROR] 上传测试失败（dd命令执行异常）"
        set_failed
        return 1
    fi
    
    # 检查文件是否完整
    UPLOAD_SIZE=$(stat -c%s "$UPLOAD_PATH" 2>/dev/null)
    if [ "$FILE_SIZE" != "$UPLOAD_SIZE" ]; then
        echo "[ERROR] 上传文件不完整（源: $FILE_SIZE bytes, 目标: $UPLOAD_SIZE bytes）"
        set_failed
        return 1
    fi
    
    # 计算速度
    TIME_DIFF=$(echo "$END_TIME - $START_TIME" | bc)
    if [ "$TIME_DIFF" != "0" ]; then
        SPEED_MB=$(echo "scale=2; $FILE_SIZE / 1048576 / $TIME_DIFF" | bc)
        echo ""
        echo "[RESULT] 上传文件大小: ${FILE_SIZE_MB} MB"
        echo "[RESULT] 上传耗时: ${TIME_DIFF} 秒"
        echo "[RESULT] 上传速度: ${SPEED_MB} MB/s"
    else
        echo "[ERROR] 上传时间计算异常"
        set_failed
        return 1
    fi
    
    sync
    echo ""
    echo "[OK] 上传测试完成"
    echo ""
}

# 函数：清理U盘上的测试文件
cleanup_usb() {
    echo "[INFO] 清理U盘上的测试文件..."
    UPLOAD_PATH="$USB_MOUNT_POINT/$UPLOAD_DIR/test_upload.bin"
    
    if [ -f "$UPLOAD_PATH" ]; then
        rm -f "$UPLOAD_PATH"
        echo "[OK] 已删除U盘文件: $UPLOAD_PATH"
    else
        echo "[WARN] 未找到上传文件"
    fi
    echo ""
}

# 函数：卸载U盘
unmount_usb() {
    echo "[INFO] 卸载U盘..."
    
    # 确保所有写入完成
    sync
    
    # 卸载U盘
    if mount | grep -q "$USB_MOUNT_POINT"; then
        umount "$USB_MOUNT_POINT" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "[OK] U盘已安全卸载: $USB_MOUNT_POINT"
        else
            echo "[ERROR] U盘卸载失败，可能有程序正在使用"
            echo "请稍后手动卸载: umount $USB_MOUNT_POINT"
        fi
    else
        echo "[WARN] U盘未挂载，无需卸载"
    fi
    echo ""
}

# 函数：清理所有测试文件
cleanup_all() {
    echo "========================================"
    echo "    清理测试环境"
    echo "========================================"
    echo ""
    
    # 清理U盘测试文件
    cleanup_usb
    
    # 卸载U盘
    unmount_usb
    
    # 清理板子内存
    cleanup_board_memory
    
    echo "[OK] 所有清理完成"
    echo ""
}

# 主函数
main() {
    # 执行测试流程
    cleanup_board_memory        # 测试前先清理板子
    check_board_space           # 检查磁盘空间
    
    # 如果空间检查失败则退出
    if [ $TEST_STATUS -eq 1 ]; then
        exit 1
    fi
    
    mount_usb                   # 挂载U盘
    check_files                 # 检查测试文件
    create_upload_dir           # 创建上传目录
    test_download_speed         # 测试下载
    test_upload_speed           # 测试上传
    cleanup_all                 # 完整清理环境（包括卸载U盘）
    
    # 输出最终结果
    print_final_result
}

# 运行主函数
main