#!/usr/bin/env bash
# Author: jaingxinyi 
# 蓝牙基础通信检测脚本
# 用法: ./bluetooth.sh <目标蓝牙名称>

set -u

TARGET_NAME=""
TARGET_MAC=""
SCAN_TIMEOUT=12
CONNECT_TIMEOUT=10
PAIR_DEVICE=1
PAIR_PIN=""
REQUEST_ONLY=0
REQUEST_HOLD=8

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
log_success() { echo -e "${GREEN}[PASS]${NC} $*"; }
log_warning() { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error()   { echo -e "${RED}[FAIL]${NC} $*" >&2; }

usage() {
    cat <<'EOF'
蓝牙基础通信检测脚本

用法:
    ./bluetooth.sh <目标蓝牙名称> [选项]

示例:
    ./bluetooth.sh "My Bluetooth Device"
    ./bluetooth.sh "My Bluetooth Device" --pin 0000
    ./bluetooth.sh "My Bluetooth Device" --no-pair

选项:
      --pin <code>           自动配对时输入 PIN/passkey，例如 0000、1234
      --scan-timeout <s>     扫描超时，默认 12 秒
      --connect-timeout <s>  连接超时，默认 10 秒
            --request-only         只验证能否发起配对请求，不要求最终配对或连接成功
            --request-hold <s>     --request-only 检测到确认/PIN 流程后保持秒数，默认 8 秒
      --no-pair              跳过配对，仅扫描和链路检测
  -h, --help                 显示帮助

判定标准:
    按名称匹配到第一个设备后，已配对 + 能连接或能读取到目标 UUID/服务信息 => 蓝牙基础通信正常
        使用 --request-only 时，只验证是否能发起配对请求并进入确认/PIN/配对流程
EOF
}

fail_with_hint() {
    log_error "$1"
    [ -n "${2:-}" ] && log_warning "$2"
    echo "ERR1100"
    exit 1
}

require_value() {
    local opt="$1" val="${2:-}"
    if [ -z "$val" ] || [ "${val#-}" != "$val" ]; then
        fail_with_hint "选项 $opt 缺少参数"
    fi
}

parse_args() {
    if [ "$#" -eq 0 ]; then usage; exit 1; fi

    while [ "$#" -gt 0 ]; do
        case "$1" in
            -h|--help)
                usage; exit 0 ;;
            --pin)
                require_value "$1" "${2:-}"
                PAIR_PIN="$2"; shift 2 ;;
            --scan-timeout)
                require_value "$1" "${2:-}"
                SCAN_TIMEOUT="$2"; shift 2 ;;
            --connect-timeout)
                require_value "$1" "${2:-}"
                CONNECT_TIMEOUT="$2"; shift 2 ;;
            --request-only)
                REQUEST_ONLY=1; shift ;;
            --request-hold)
                require_value "$1" "${2:-}"
                REQUEST_HOLD="$2"; shift 2 ;;
            --no-pair)
                PAIR_DEVICE=0; shift ;;
            --*)
                fail_with_hint "未知选项: $1" "使用 ./bluetooth.sh --help 查看支持的参数。" ;;
            *)
                [ -n "$TARGET_NAME" ] && fail_with_hint "只能指定一个目标蓝牙名称，多余参数: $1"
                TARGET_NAME="$1"; shift ;;
        esac
    done

    [ -n "$TARGET_NAME" ] || fail_with_hint "目标蓝牙名称不能为空" "示例: ./bluetooth.sh \"My Bluetooth Device\""

    if [ -n "$PAIR_PIN" ] && [ "$PAIR_DEVICE" -eq 0 ]; then
        fail_with_hint "--pin 不能和 --no-pair 同时使用"
    fi

    if [ "$REQUEST_ONLY" -eq 1 ] && [ "$PAIR_DEVICE" -eq 0 ]; then
        fail_with_hint "--request-only 不能和 --no-pair 同时使用"
    fi

    for vname in SCAN_TIMEOUT CONNECT_TIMEOUT REQUEST_HOLD; do
        v=$(eval "printf '%s' \"\$$vname\"")
        echo "$v" | grep -Eq '^[0-9]+$' || fail_with_hint "$vname 必须是秒数: $v"
    done
}

ensure_bluetooth_ready() {
    log_info "检查本机蓝牙服务和适配器状态"

    if command -v systemctl >/dev/null 2>&1 && ! systemctl is-active --quiet bluetooth; then
        log_warning "bluetooth 服务未运行，尝试启动"
        sudo systemctl start bluetooth || fail_with_hint "无法启动 bluetooth 服务"
    fi

    bluetoothctl show >/dev/null 2>&1 \
        || fail_with_hint "未检测到可用蓝牙适配器" "请确认蓝牙硬件、驱动和 BlueZ 服务。"

    if ! bluetoothctl show | grep -q 'Powered: yes'; then
        log_warning "蓝牙适配器未打开，尝试 power on"
        bluetoothctl power on >/dev/null 2>&1 \
            || fail_with_hint "蓝牙适配器 power on 失败"
    fi

    log_success "本机蓝牙已就绪"
}

find_first_cached_device_by_name() {
    bluetoothctl devices 2>/dev/null | awk -v target="$TARGET_NAME" '
        $1 == "Device" {
            mac = $2
            name = $0
            sub(/^Device[[:space:]]+[^[:space:]]+[[:space:]]+/, "", name)
            if (name == target) {
                print mac
                exit
            }
        }
    '
}

find_first_scanned_device_by_name() {
    local scan_log="$1"

    awk -v target="$TARGET_NAME" '
        {
            sub(/\r$/, "")
            for (i = 1; i <= NF; i++) {
                if ($i == "Device" && (i + 1) <= NF && $(i + 1) ~ /^([0-9A-Fa-f][0-9A-Fa-f]:){5}[0-9A-Fa-f][0-9A-Fa-f]$/) {
                    mac = $(i + 1)
                    name = ""
                    for (j = i + 2; j <= NF; j++) {
                        name = name (name == "" ? "" : " ") $j
                    }
                    sub(/^Name:[[:space:]]*/, "", name)
                    if (name == target) {
                        print mac
                        exit
                    }
                }
            }
        }
    ' "$scan_log"
}

discover_device() {
    log_info "按蓝牙名称查找目标: $TARGET_NAME"

    TARGET_MAC=$(find_first_cached_device_by_name)
    if [ -n "$TARGET_MAC" ]; then
        log_success "目标已存在于本机蓝牙缓存: $TARGET_NAME ($TARGET_MAC)"
        return 0
    fi

    log_info "目标不在缓存中，开始扫描 ${SCAN_TIMEOUT}s"
    local scan_log="/tmp/bt-scan-$$.log"
    timeout "$SCAN_TIMEOUT" bluetoothctl scan on >"$scan_log" 2>&1 || true
    bluetoothctl scan off >/dev/null 2>&1 || true

    TARGET_MAC=$(find_first_scanned_device_by_name "$scan_log")
    [ -n "$TARGET_MAC" ] || TARGET_MAC=$(find_first_cached_device_by_name)
    rm -f "$scan_log"

    [ -n "$TARGET_MAC" ] && bluetoothctl info "$TARGET_MAC" >/dev/null 2>&1 \
        || fail_with_hint \
            "未扫描到名称为 '$TARGET_NAME' 的目标设备" \
            "请让对端蓝牙处于可发现状态，确认蓝牙名称完全一致，并缩短两端距离。"

    log_success "扫描到目标设备: $TARGET_NAME ($TARGET_MAC)"
}

pair_with_expect() {
    PAIR_MAC="$TARGET_MAC" PAIR_CODE="$PAIR_PIN" timeout 60 expect <<'EXPECTEOF'
set timeout 55
set mac $env(PAIR_MAC)
set pin ""
if {[info exists env(PAIR_CODE)]} { set pin $env(PAIR_CODE) }

proc wait_prompt {} {
    expect {
        -re {\[[^]]+\]# $} {}
        -re {# $} {}
        timeout { puts "BLUETOOTHCTL_PROMPT_TIMEOUT"; exit 1 }
        eof { exit 1 }
    }
}

proc send_setup_cmd {cmd} {
    send -- "$cmd\r"
    expect {
        -nocase -re {failed to register agent object|no agent is registered|already registered} {
            # agent 注册失败时继续：bluetoothd 自身或对端可接管确认流程
        }
        -re {\[[^]]+\]# $} {}
        -re {# $} {}
        timeout { puts "SETUP_TIMEOUT"; send -- "quit\r"; exit 1 }
        eof { exit 1 }
    }
}

proc send_pin {pin} {
    if {$pin eq ""} { puts "PIN_REQUIRED"; exit 20 }
    send -- "$pin\r"
}

spawn bluetoothctl
wait_prompt

send_setup_cmd "agent KeyboardDisplay"
send_setup_cmd "default-agent"

send -- "pair $mac\r"
expect {
    -nocase -re {confirm passkey.*\(yes/no\).*:}       { send -- "yes\r"; exp_continue }
    -nocase -re {request confirmation.*\(yes/no\).*:}  { send -- "yes\r"; exp_continue }
    -nocase -re {authorize service.*\(yes/no\).*:}     { send -- "yes\r"; exp_continue }
    -nocase -re {(enter|request).*pin.*:}              { send_pin $pin;   exp_continue }
    -nocase -re {(enter|request).*passkey.*:}          { send_pin $pin;   exp_continue }
    -nocase -re {pairing successful} {
        send -- "trust $mac\r"
        expect { -nocase -re {trust succeeded|successful|#} {} timeout {} }
        send -- "quit\r"; exit 0
    }
    -nocase -re {already exists} {
        send -- "trust $mac\r"
        expect { -re {#} {} timeout {} }
        send -- "quit\r"; exit 0
    }
    -nocase -re {failed to pair:.*} { send -- "quit\r"; exit 1 }
    timeout { puts "PAIR_TIMEOUT"; send -- "quit\r"; exit 1 }
    eof     { exit 1 }
}
EXPECTEOF
}

test_pair_request_with_expect() {
    PAIR_MAC="$TARGET_MAC" PAIR_REQUEST_HOLD="$REQUEST_HOLD" timeout $((REQUEST_HOLD + 45)) expect <<'EXPECTEOF'
set timeout 40
set mac $env(PAIR_MAC)
set hold $env(PAIR_REQUEST_HOLD)

proc wait_prompt {} {
    expect {
        -re {\[[^]]+\]# $} {}
        -re {# $} {}
        timeout { puts "BLUETOOTHCTL_PROMPT_TIMEOUT"; exit 1 }
        eof { exit 1 }
    }
}

proc send_setup_cmd {cmd} {
    send -- "$cmd\r"
    expect {
        -nocase -re {failed to register agent object|no agent is registered|already registered} {
            # agent 注册失败时继续：bluetoothd 自身或对端可接管确认流程
        }
        -re {\[[^]]+\]# $} {}
        -re {# $} {}
        timeout { puts "SETUP_TIMEOUT"; send -- "quit\r"; exit 1 }
        eof { exit 1 }
    }
}

proc pass_after_hold {message hold} {
    puts $message
    if {$hold > 0} { after [expr {$hold * 1000}] }
    exit 0
}

spawn bluetoothctl
wait_prompt
send_setup_cmd "agent KeyboardDisplay"
send_setup_cmd "default-agent"

send -- "pair $mac\r"
expect {
    -nocase -re {confirm passkey.*\(yes/no\).*:}       { pass_after_hold "PAIR_REQUEST_CONFIRMATION" $hold }
    -nocase -re {request confirmation.*\(yes/no\).*:}  { pass_after_hold "PAIR_REQUEST_CONFIRMATION" $hold }
    -nocase -re {authorize service.*\(yes/no\).*:}     { pass_after_hold "PAIR_REQUEST_CONFIRMATION" $hold }
    -nocase -re {(enter|request).*pin.*:}              { pass_after_hold "PAIR_REQUEST_PIN" $hold }
    -nocase -re {(enter|request).*passkey.*:}          { pass_after_hold "PAIR_REQUEST_PASSKEY" $hold }
    -nocase -re {pairing successful}                   { puts "PAIR_REQUEST_PAIRED"; send -- "quit\r"; exit 0 }
    -nocase -re {already exists|already paired}         { puts "PAIR_REQUEST_ALREADY_PAIRED"; send -- "quit\r"; exit 0 }
    -nocase -re {failed to pair:.*}                     { send -- "quit\r"; exit 1 }
    timeout                                             { puts "PAIR_REQUEST_TIMEOUT"; send -- "quit\r"; exit 1 }
    eof                                                 { exit 1 }
}
EXPECTEOF
}

pair_with_simple_session() {
    # 非交互单命令模式：bluetoothd 使用内置 agent 处理确认，避免管道方式导致 agent 注册失败
    timeout 60 bluetoothctl pair "$TARGET_MAC"
}

pair_and_trust() {
    [ "$PAIR_DEVICE" -eq 0 ] && { log_info "已指定 --no-pair，跳过配对"; return 0; }

    local paired
    paired=$(bluetoothctl info "$TARGET_MAC" 2>/dev/null | awk '/Paired:/ {print $2; exit}')

    if [ "$paired" = "yes" ]; then
        log_success "目标已配对"
    else
        log_info "目标未配对，尝试配对（对端可能需要手动确认）"

        local pair_rc
        if command -v expect >/dev/null 2>&1; then
            [ -n "$PAIR_PIN" ] \
                && log_info "已提供 --pin，将自动输入配对码" \
                || log_info "检测到 expect，将自动处理本机侧 yes/no 确认"
            pair_with_expect; pair_rc=$?
        else
            log_warning "未安装 expect，使用非交互配对；对于需要弹窗确认的设备，请在对端及时点击确认"
            pair_with_simple_session; pair_rc=$?
        fi

        [ "$pair_rc" -eq 20 ] && fail_with_hint \
            "目标要求输入 PIN/passkey，但未提供配对码" \
            "请加 --pin 参数，例如 --pin 0000；Windows 数字确认还需要在对端点确认。"

        [ "$pair_rc" -ne 0 ] && fail_with_hint \
            "配对失败" \
            "请确认对端允许配对、弹窗已确认、旧配对记录已删除；固定 PIN 设备可试 --pin 0000 或 --pin 1234。"

        sleep 1
        paired=$(bluetoothctl info "$TARGET_MAC" 2>/dev/null | awk '/Paired:/ {print $2; exit}')
        [ "$paired" != "yes" ] && fail_with_hint \
            "配对流程结束，但 BlueZ 仍显示未配对" \
            "对端可能拒绝了配对或未点确认，请删除两端旧配对记录后重试。"

        log_success "配对完成"
    fi

    bluetoothctl trust "$TARGET_MAC" >/dev/null 2>&1 || true
}

test_pair_request_only() {
    log_info "仅验证是否能向目标发起配对请求，不要求最终配对或连接成功"
    log_info "如果对端弹出配对提示，将保持 ${REQUEST_HOLD}s 便于观察"

    command -v expect >/dev/null 2>&1 \
        || fail_with_hint \
            "--request-only 需要安装 expect 才能可靠观察配对确认/PIN 流程" \
            "请先安装 expect，或使用完整配对检测模式。"

    local request_rc
    test_pair_request_with_expect; request_rc=$?

    [ "$request_rc" -eq 21 ] && fail_with_hint \
        "本机 BlueZ 无法注册或启用配对 agent" \
        "请重启 bluetooth 服务后重试：sudo systemctl restart bluetooth"

    [ "$request_rc" -ne 0 ] && fail_with_hint \
        "未能确认配对请求已进入对端确认/PIN 流程" \
        "请确认电脑蓝牙已开启、允许被发现，且两端旧配对记录已删除。"

    log_success "已发起配对请求并进入确认/PIN/配对流程，可按该标准判定测试通过"
}

test_basic_link() {
    log_info "执行蓝牙基础通信检测"

    local info paired
    info=$(bluetoothctl info "$TARGET_MAC" 2>/dev/null || true)
    paired=$(printf '%s\n' "$info" | awk '/Paired:/ {print $2; exit}')

    [ "$paired" != "yes" ] && [ "$PAIR_DEVICE" -eq 1 ] \
        && fail_with_hint "目标未配对，无法判定蓝牙通信正常"

    log_info "尝试连接以触发服务发现"
    timeout "$CONNECT_TIMEOUT" bluetoothctl connect "$TARGET_MAC" \
        >/tmp/bt-connect.log 2>&1 || true
    sleep 1

    info=$(bluetoothctl info "$TARGET_MAC" 2>/dev/null || true)
    local connected services_resolved uuid_count
    connected=$(printf '%s\n' "$info" | awk '/Connected:/ {print $2; exit}')
    services_resolved=$(printf '%s\n' "$info" | awk '/ServicesResolved:/ {print $2; exit}')
    uuid_count=$(printf '%s\n' "$info" | awk '/UUID:/ {c++} END {print c+0}')

    echo "---------- bluetooth info ----------"
    printf '%s\n' "$info" | grep -E 'Name:|Alias:|Paired:|Trusted:|Connected:|ServicesResolved:|UUID:'
    echo "------------------------------------"

    paired=$(printf '%s\n' "$info" | awk '/Paired:/ {print $2; exit}')

    if [ "$paired" = "yes" ] && \
       { [ "$connected" = "yes" ] || [ "$services_resolved" = "yes" ] || [ "$uuid_count" -gt 0 ]; }
    then
        log_success "蓝牙基础通信正常：已配对，并且能连接或读取到目标服务信息"
        return 0
    fi

    [ -s /tmp/bt-connect.log ] \
        && { log_warning "bluetoothctl connect 输出:"; sed 's/^/  /' /tmp/bt-connect.log >&2; }

    fail_with_hint \
        "蓝牙基础通信检测失败" \
        "目标需满足：已配对，并且能完成连接/服务发现/UUID 读取中的任一项。"
}

main() {
    parse_args "$@"
    ensure_bluetooth_ready
    discover_device
    [ "$REQUEST_ONLY" -eq 1 ] && { test_pair_request_only; echo "SUC1100"; return 0; }
    pair_and_trust
    test_basic_link
    echo "SUC1100"
}

main "$@"