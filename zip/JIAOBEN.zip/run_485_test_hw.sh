#!/bin/bash
sudo ./rk485_test_hw
