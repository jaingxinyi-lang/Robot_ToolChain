#include "led_driver.h"
#include <iostream>
#include <unistd.h>
#include <signal.h>
#include <iomanip>

bool keep_running = true;

void int_handler(int dummy) {
    keep_running = false;
}

void print_usage(const char* prog_name) {
    std::cout << "用法: " << prog_name << " [选项]" << std::endl;
    std::cout << "选项:" << std::endl;
    std::cout << "  -c, --cycles <次数>    循环次数 (默认: 10)" << std::endl;
    std::cout << "  -d, --delay <毫秒>     颜色切换延迟 (默认: 1000ms)" << std::endl;
    std::cout << "  -h, --help             显示帮助信息" << std::endl;
    std::cout << std::endl;
    std::cout << "示例:" << std::endl;
    std::cout << "  " << prog_name << " -c 5 -d 500" << std::endl;
    std::cout << "  " << prog_name << " --cycles 20 --delay 200" << std::endl;
}

int main(int argc, char* argv[]) {
    int max_cycles = 10;
    int delay_ms = 1000;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if ((arg == "-c" || arg == "--cycles") && i + 1 < argc) {
            max_cycles = atoi(argv[++i]);
        } else if ((arg == "-d" || arg == "--delay") && i + 1 < argc) {
            delay_ms = atoi(argv[++i]);
        } else if (arg == "-h" || arg == "--help") {
            print_usage(argv[0]);
            return 0;
        }
    }

    std::cout << "============================================" << std::endl;
    std::cout << "       ARGB LED 红绿蓝循环测试程序          " << std::endl;
    std::cout << "============================================" << std::endl;
    std::cout << "循环次数: " << max_cycles << std::endl;
    std::cout << "切换延迟: " << delay_ms << " ms" << std::endl;
    std::cout << "--------------------------------------------" << std::endl;

    signal(SIGINT, int_handler);

    std::cout << "[初始化] 正在初始化 SPI 设备..." << std::endl;
    int init_result = led_init();
    
    if (init_result < 0) {
        std::cerr << "[错误] SPI设备初始化失败!" << std::endl;
        std::cerr << "可能的原因:" << std::endl;
        std::cerr << "  1. SPI设备 /dev/spidev3.1 不存在" << std::endl;
        std::cerr << "  2. 没有权限访问SPI设备 (需要root权限)" << std::endl;
        std::cerr << "  3. SPI驱动未加载" << std::endl;
        std::cerr << "" << std::endl;
        std::cerr << "解决方案:" << std::endl;
        std::cerr << "  1. 检查SPI设备是否存在: ls -la /dev/spidev*" << std::endl;
        std::cerr << "  2. 使用root权限运行: sudo ./argb_test" << std::endl;
        std::cerr << "  3. 检查SPI驱动是否加载: lsmod | grep spi" << std::endl;
        return -1;
    }
    
    std::cout << "[成功] SPI设备初始化完成" << std::endl;
    std::cout << "[启动] 开始红绿蓝颜色循环 (循环" << max_cycles << "次后自动结束)" << std::endl;
    std::cout << "--------------------------------------------------------" << std::endl;

    unsigned char colors[3][3] = {
        {0xFF, 0x00, 0x00},  // 红色
        {0x00, 0xFF, 0x00},  // 绿色
        {0x00, 0x00, 0xFF}   // 蓝色
    };

    const char* color_names[] = {"红色", "绿色", "蓝色"};
    int color_index = 0;
    int cycle_count = 0;

    while (keep_running && cycle_count < max_cycles) {
        unsigned char r = colors[color_index][0];
        unsigned char g = colors[color_index][1];
        unsigned char b = colors[color_index][2];

        printf("[LED] 当前颜色: %s (R:0x%02X G:0x%02X B:0x%02X) | 循环: %d/%d\n",
               color_names[color_index], r, g, b, cycle_count + 1, max_cycles);

        led_rgb_update(r, g, b);

        usleep(delay_ms * 1000);

        color_index = (color_index + 1) % 3;
        
        if (color_index == 0) {
            cycle_count++;
        }
    }

    std::cout << "\n[停止] 关闭 LED..." << std::endl;
    led_rgb_update(0x00, 0x00, 0x00);

    if (cycle_count >= max_cycles) {
        std::cout << "[完成] 已完成 " << max_cycles << " 次循环测试" << std::endl;
    } else {
        std::cout << "[中断] 测试被用户中断" << std::endl;
    }
    
    std::cout << "ARGB LED 测试程序已停止。" << std::endl;
    return 0;
}