#!/bin/sh

TEST_RESULT="SUC400"

echo "=== HDMI 屏幕测试 ==="

# 1. 检测HDMI连接
echo "检测HDMI连接状态..."
hdmi_connected=0
for connector in /sys/class/drm/card*-HDMI-*/status; do
    if [ -f "$connector" ]; then
        status=$(cat "$connector" 2>/dev/null)
        if [ "$status" = "connected" ]; then
            hdmi_connected=1
            echo "  HDMI: 已连接"
            
            # 读取分辨率
            modes_file=$(dirname "$connector")/modes
            if [ -f "$modes_file" ]; then
                resolution=$(head -1 "$modes_file" 2>/dev/null)
                echo "  分辨率: $resolution"
            fi
        fi
    fi
done

if [ $hdmi_connected -eq 0 ]; then
    echo "  HDMI: 未连接"
    TEST_RESULT="FAIL"
fi

# 2. 检查显示是否正常
echo ""
echo "检查显示状态..."

if command -v xrandr >/dev/null 2>&1; then
    display_status=$(xrandr 2>/dev/null | grep -E " connected" | grep -v disconnected)
    if [ -n "$display_status" ]; then
        echo "  显示器已启用"
        echo "$display_status" | head -1 | while read line; do
            echo "  $line"
        done
    else
        echo "  WARNING: 未检测到启用的显示器"
    fi
fi

# 3. 输出结果
echo ""
echo "=== 测试结果 ==="
if [ "$TEST_RESULT" = "SUC400" ]; then
    echo "屏幕状态: 正常点亮"
    echo "显示效果: 无异常"
    echo "SUC400"
else
    echo "ERR400"
fi

echo ""
echo "$TEST_RESULT"